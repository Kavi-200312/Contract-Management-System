import React, { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { checkAuthentication } from "../utils/auth";

const PrivateRoute = ({ element }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(null);

  useEffect(() => {
    const verifyAuth = async () => {
      const isValid = await checkAuthentication();
      setIsAuthenticated(isValid);
    };

    verifyAuth();
  }, []);

  if (isAuthenticated === null) {
    // Show a loader while authentication is being verified
    return <div>Loading...</div>;
  }

  return isAuthenticated ? element : <Navigate to="/cms" />;
};

export default PrivateRoute;
