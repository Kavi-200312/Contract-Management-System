
import axiosInstance from "./axiosInstance";

// Function to check if the user is authenticated
export const checkAuthentication = async () => {
  const token = localStorage.getItem("token");

  if (!token) {
    return false; 
  }

  try {
    // Verify the token and hash with the backend
    const response = await axiosInstance.post("/authendicate", { token });
    return response.data.isValid; // Return if the token is valid
  } catch (error) {
    console.error("Error verifying token:", error);
    return false; // Authentication failed
  }
};
