// baseURL: `${"http://192.168.29.14:7500"}/cms`,



import axios from 'axios';

// Function to get the token from localStorage
const getToken = () => {
  return localStorage.getItem('token');  
};

// Create axios instance
const axiosInstance = axios.create({
  baseURL: `${window.location.origin}/cms`,
  timeout: 5000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add Authorization header with token
axiosInstance.interceptors.request.use(
  (config) => {
    const token = getToken(); 
    console.log(token) 

    if (token) {
      // Add the token in the Authorization header if it's available
      config.headers['Authorization'] = `Bearer ${token}`;  
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Handle response (e.g., token expiration)
axiosInstance.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response && error.response.status === 401) {
      console.error('Unauthorized: Redirecting to login...');
      
      // Remove token from localStorage if it's expired or invalid
      localStorage.removeItem('token');
      
      // Redirect to login page
      window.location.href = '/'; 
    }
    return Promise.reject(error);
  }
);

export default axiosInstance;


