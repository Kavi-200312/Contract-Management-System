import {
  createBrowserRouter,
  Navigate,
  RouterProvider,
} from "react-router-dom";
import "./App.css";
import Dashboard from "./components/dashboard/Dashboard";
import Layout from "./components/layout/Layout";
import QuillEditor from "./components/quill/QuillEdit";
import Client from "./components/client/Client";
import LoginPage from "./components/loginPage/Login";
import PrivateRoute from "./utils/PrivateRoute"; // Import PrivateRoute
import LandingPage from "./components/langingPage/LandingPage";
import ListofDocument from "./components/listofDocument/ListofDocument";
import SharedWithMe from "./components/sharedDocument/SharedDocument";
import NotFoundPage from "./components/errorPage/ErrorPage";

function App() {
  const router = createBrowserRouter([
    { path: "/cms/login", element: <LoginPage /> }, // Public Route
    { path: "/cms", element: <LandingPage /> }, // Public Route
    { path: "/", element: <Navigate to="/cms" /> }, // Redirect to login
    {
      path: "/cms/nav",
      element: <PrivateRoute element={<Layout />} />, // Protected Layout Route
      children: [
        { index: true, element: <PrivateRoute element={<Dashboard />} /> },
        {
          path: "quillEditor",
          element: <PrivateRoute element={<QuillEditor />} />,
        },
        {
          path: "listofclient",
          element: <PrivateRoute element={<Client />} />,
        },
        {
          path: "Documents",
          element: <PrivateRoute element={<ListofDocument />} />,
        },
        {
          path: "SharedWithMe",
          element: <PrivateRoute element={<SharedWithMe />} />,
        },
      ],
    },
    { path: "*", element: <NotFoundPage /> },
  ]);

  return <RouterProvider router={router} />;
}

export default App;
