import React, { useEffect, useState } from "react";
import axiosInstance from "../../utils/axiosInstance";
import { toast, ToastContainer } from "react-toastify";
import styles from "./ListofDocument.module.css";
import { useNavigate } from "react-router-dom";
import {
  faCheck,
  faFolderOpen,
  faTimes,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const ListofDocument = () => {
  const [documents, setDocuments] = useState([]);
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [shareDetails, setShareDetails] = useState(""); // Collaborator or client
  const [newParty, setNewParty] = useState(null);
  const [selectedParties, setSelectedParties] = useState([]);
  const [permission, setPermission] = useState(""); // Collaborator permission
  const [checkedParties, setCheckedParties] = useState([]); // Parties with permissions
  const navigate = useNavigate();
  const [showPendingPopup, setShowPendingPopup] = useState(false);

  const handleApprovePendingFile = async (
    document,
    selectedDocument,
    approval
  ) => {
    try {
      const updatingDocument = {
        ...document,
        size: selectedDocument.size,
        uniqueIdDoc: selectedDocument.uniqueIdDoc,
        approval,
      };
      if (updatingDocument.uniqueIdDoc) {
        // If uniqueIdDoc exists, call updateDocumentDetails API
        const response = await axiosInstance.post(
          "/handleApprovePendingFile",
          updatingDocument
        );
        if (response.status === 200) {
          toast.success("Document Approval updated");
        } else if (response.data.code) {
          toast.error(response.data.message);
        } else {
          toast.error("something went wrong");
        }
      } else {
        toast.error("Data insufficient");
      }
    } catch (error) {
      toast.error("server Error");
    }
  };

  const handleOpenFile = async (document) => {
    try {
      const filePath = document.filePath;

      if (!filePath) {
        toast.info("File is missing...");
        // setTimeout(() => {
        //   navigate("/cms/nav/quillEditor", {
        //     state: { contentFromFile: "", formValues: document },
        //   });
        // }, 3000);
        return;
      }

      const response = await axiosInstance.get(
        `/getDocumentContent/${filePath}`
      );
      const fileContent = response.data.content;

      navigate("/cms/nav/quillEditor", {
        state: { contentFromFile: fileContent, formValues: document },
      });
    } catch (error) {
      console.error("Error opening file:", error);
      toast.error("Failed to open file.");
    }
  };
  const handleOpenPendingFile = async (document, selectedDocument) => {
    try {
      const updatingDocument = {
        ...document,
        size: selectedDocument.size,
        uniqueIdDoc: selectedDocument.uniqueIdDoc,
      };
      console.log(updatingDocument);
      console.log(document);

      const filePath = document.proposedFilePath;

      if (!filePath) {
        toast.info("File is missing...");
        return;
      }

      const response = await axiosInstance.get(
        `/getDocumentContent/${filePath}`
      );
      const fileContent = response.data.content;

      navigate("/cms/nav/quillEditor", {
        state: { contentFromFile: fileContent, formValues: updatingDocument },
      });
    } catch (error) {
      console.error("Error opening file:", error);
      toast.error("Failed to open file.");
    }
  };

  useEffect(() => {
    const fetchClients = async () => {
      try {
        const response = await axiosInstance.get("/getclients");
        setClients(response.data.data);
      } catch (err) {
        toast.error("Failed to fetch client data");
      }
    };

    fetchClients();
  }, []);
  const fetchDocuments = async () => {
    try {
      const response = await axiosInstance.get("/getDocuments");
      setDocuments(response.data.documents);
      setLoading(false);
    } catch (err) {
      setError("No documents.");
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchDocuments();
  }, []);

  const handleModalOpen = (document, shareDetailsType) => {
    setSelectedDocument(document);
    setShareDetails(shareDetailsType);
    setModalOpen(true);
    setSelectedParties(document.counterParties || []);
    setCheckedParties(
      document.counterParties?.map((party) => ({
        ...party,
        permission: "Read Only", // Default permission
        selected: true,
      })) || []
    );
    setPermission("");
  };
  const pendingDocument = (document) => {
    setSelectedDocument(document);
    setShowPendingPopup(true);
    setSelectedParties(document.pendingUpdates || []);
  };
  const handleModalClose = () => {
    setModalOpen(false);
    setSelectedDocument(null);
    setShareDetails("");
    setCheckedParties([]);
  };

  const handlePermissionChange = (e) => {
    setPermission(e.target.value);
  };

  const handlePartySelection = (party) => {
    setCheckedParties((prev) =>
      prev.map((p) =>
        p.clientName === party.clientName ? { ...p, selected: !p.selected } : p
      )
    );
  };

  const handlePartyPermissionChange = (party, permission) => {
    setCheckedParties((prev) =>
      prev.map((p) =>
        p.clientName === party.clientName ? { ...p, permission } : p
      )
    );
  };

  const handleAddParty = () => {
    if (!newParty) {
      toast.error("Please select a client to add.");
      return;
    }

    const partyExists = checkedParties.some(
      (party) => party.clientName === newParty.name
    );

    if (partyExists) {
      toast.error("This party is already added.");
      return;
    }

    // Create new party object with dynamic party number
    const addedParty = {
      party: `party ${checkedParties.length + 1}`, // Adjusting the party number
      clientName: newParty.name,
      clientMobileNumber: newParty.mobileNumber,
      permission: "Read Only", // Default permission
      selected: true,
    };

    setCheckedParties([...checkedParties, addedParty]);
    setNewParty(null); // Resetting new party input after adding
  };

  const handleSaveParty = async () => {
    if (!selectedDocument || !newParty) return;

    // Adding the selected party to the list of selected parties
    const updatedParties = [...selectedParties, newParty];

    try {
      const response = await axiosInstance.post("/updateParty", {
        documentId: selectedDocument.uniqueIdDoc,
        newParty: {
          ...newParty,
          party: `party ${selectedDocument.counterParties.length + 1}`, // Increment length to reflect the next party number
        },
      });
      if ((response.data.message = "Party added successfully.")) {
        toast.success("Party saved successfully!");
        // Update the parties list with the new party
        setSelectedParties(updatedParties);
        setNewParty(null); // Reset party selection
        fetchDocuments();
      } else {
        toast.error("Failed to save party.");
      }
    } catch (error) {
      console.error("Error saving party:", error);
      toast.error("Error saving party.");
    }
  };

  const handleShareDetails = async () => {
    if (!selectedDocument) return;

    const payload = {
      ...selectedDocument,
      counterParties: checkedParties.filter((party) => party.selected), // Only send selected parties
      shareDetails,
      permission: shareDetails === "collaborator" ? permission : null,
    };

    try {
      const response = await axiosInstance.post("/sendDetailstoCC", payload);
      if (response.data.code === 404) {
        toast.error(response.data.message);
      } else {
        toast.success("Details shared successfully!");
        setPermission("");
        setCheckedParties([]);

        // Call status API only if shareDetails is "client"
        if (shareDetails === "client") {
          try {
            const statusResponse = await axiosInstance.put("./upateStatus", {
              uniqueIdDoc: selectedDocument.uniqueIdDoc,
              status: "FollowUp",
            });
            if (statusResponse.status === 200) {
              toast.success("Status updated successfully!");
            } else {
              toast.error("Failed to update status.");
            }
          } catch (statusError) {
            console.error("Error updating status:", statusError);
            toast.error("An error occurred while updating the status.");
          }
        }
      }
    } catch (error) {
      console.error("Error sending details:", error);
      toast.error("Failed to send details.");
    }
  };

  if (loading)
    return (
      <div className={styles.loaderContainer}>
        <div className={styles.loader}></div>
      </div>
    );
  if (error)
    return (
      <div className={styles.errorContainer}>
        <div className={styles.errorLoader}>{error}</div>
      </div>
    );

  const availableClients = clients.filter(
    (client) =>
      !checkedParties.some((party) => party.clientName === client.name)
  );

  return (
    <div>
      <ToastContainer />
      <button
        className={styles.AddDocumentInDash}
        onClick={() => {
          navigate("/cms/nav", { state: { value: true } });
        }}
      >
        Add Document
      </button>
      <h1>Document List</h1>
      <table className={styles.table}>
        <thead>
          <tr>
            <th className={styles.th}>Document Name</th>
            <th className={styles.th}>Size</th>
            <th className={styles.th}>Collaborator</th>
            <th className={styles.th}>Parties</th>
            <th className={styles.th}>Status</th>
            <th className={styles.th}>Open File</th>
            <th className={styles.th}>pending approvals</th>
          </tr>
        </thead>
        <tbody>
          {documents.length > 0 ? (
            documents.map((document, index) => (
              <tr key={index}>
                <td className={styles.td}>{document.documentName}</td>
                <td className={styles.td}>{document.size}</td>
                <td className={styles.td}>
                  <button
                    className={styles.partyButton}
                    onClick={() => handleModalOpen(document, "collaborator")}
                  >
                    Collaborator
                  </button>
                </td>
                <td className={styles.td}>
                  <button
                    className={styles.partyButton}
                    onClick={() => handleModalOpen(document, "client")}
                  >
                    Parties
                  </button>
                </td>
                <td className={styles.td}>{document.status}</td>
                <td className={styles.td}>
                  <button
                    className={styles.partyButton}
                    onClick={() => {
                      handleOpenFile(document);
                    }}
                  >
                    File
                  </button>
                </td>
                <td>
                  <button
                    className={styles.td}
                    onClick={() => pendingDocument(document)}
                    style={{ padding: "4px 8px", borderRadius: "4px" }}
                  >
                    open
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td
                colSpan="7"
                className={styles.td}
                style={{ textAlign: "center" }}
              >
                No Documents found.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {modalOpen && selectedDocument && (
        <div className={styles.modal} onClick={handleModalClose}>
          <div
            className={styles.modalContent}
            onClick={(e) => e.stopPropagation()}
          >
            <h2>
              {shareDetails === "collaborator"
                ? "Collaborator Details"
                : "Parties"}
            </h2>

            {shareDetails === "collaborator" ? (
              <>
                <p>
                  <strong>Name:</strong> {selectedDocument.collaboratorName}
                </p>
                <p>
                  <strong>Mobile:</strong>{" "}
                  {selectedDocument.collaboratorMobileNumber}
                </p>

                <div className={styles.permissionCollaborator}>
                  <label>
                    <input
                      type="radio"
                      name="permission"
                      value="Read Only"
                      onChange={handlePermissionChange}
                    />
                    Read Only
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="permission"
                      value="Write"
                      onChange={handlePermissionChange}
                    />
                    Write
                  </label>
                </div>
                <button
                  className={styles.savePartyButton}
                  onClick={handleShareDetails}
                  disabled={!permission}
                >
                  Share Details
                </button>
              </>
            ) : (
              <>
                <ul className={styles.partyList}>
                  {checkedParties.map((party, idx) => (
                    <li key={idx} className={styles.partyListItem}>
                      <div className={styles.partyListItemDetails}>
                        {idx !== 0 && ( // Hide the checkbox for the first party
                          <input
                            type="checkbox"
                            className={styles.partyCheckbox}
                            checked={party.selected}
                            onChange={() => handlePartySelection(party)}
                          />
                        )}
                        <span className={styles.partyDetails}>
                          {party.clientName} - {party.clientMobileNumber}
                        </span>
                      </div>
                      {idx !== 0 && ( // Hide the radio buttons for the first party
                        <div className={styles.radioGroup}>
                          <label className={styles.radioLabel}>
                            <input
                              type="radio"
                              name={`permission-${idx}`}
                              value="Read Only"
                              onChange={() =>
                                handlePartyPermissionChange(party, "Read Only")
                              }
                              checked={party.permission === "Read Only"}
                            />
                            Read Only
                          </label>
                          <label className={styles.radioLabel}>
                            <input
                              type="radio"
                              name={`permission-${idx}`}
                              value="Write"
                              onChange={() =>
                                handlePartyPermissionChange(party, "Write")
                              }
                              checked={party.permission === "Write"}
                            />
                            Write
                          </label>
                        </div>
                      )}
                    </li>
                  ))}
                </ul>

                <select
                  className={styles.selectClient}
                  onChange={(e) =>
                    setNewParty(
                      availableClients.find(
                        (client) => client.name === e.target.value
                      )
                    )
                  }
                >
                  <option value="">Select Client</option>
                  {availableClients.map((client, idx) => (
                    <option key={idx} value={client.name}>
                      {client.name} - {client.mobileNumber}
                    </option>
                  ))}
                </select>
                <button
                  className={styles.addPartyButton}
                  onClick={handleAddParty}
                >
                  Add Party
                </button>
                {newParty && (
                  <button
                    className={styles.savePartyButton}
                    onClick={handleSaveParty}
                  >
                    Save Party
                  </button>
                )}
                <button
                  className={styles.savePartyButton}
                  onClick={handleShareDetails}
                >
                  Share Details
                </button>
              </>
            )}

            <button className={styles.closeModalBtn} onClick={handleModalClose}>
              X
            </button>
          </div>
        </div>
      )}

      {showPendingPopup && selectedDocument && (
        <div
          className={styles.modal}
          onClick={() => setShowPendingPopup(false)}
        >
          <div
            className={`${styles.pendingList123} ${styles.modalContent} `}
            onClick={(e) => e.stopPropagation()}
          >
            <h2>Pending Approvals</h2>
            <ul className={styles.pendingList}>
              {selectedDocument.pendingUpdates.map((update, idx) => (
                <li key={idx} className={styles.pendingListItem}>
                  <div className={styles.pendingItemDetails}>
                    <p className={styles.pendingUpdatedBy}>
                      <strong>Updated By:</strong> {update.updatedBy}
                    </p>
                    <p className={styles.pendingTimestamp}>
                      <strong>Timestamp:</strong>{" "}
                      {new Date(update.timestamp).toLocaleString()}
                    </p>
                  </div>

                  <div className={styles.pendingActions}>
                    <button
                      className={styles.pendingOpenFileButton}
                      onClick={() =>
                        handleOpenPendingFile(update, selectedDocument)
                      }
                    >
                      <FontAwesomeIcon
                        style={{ color: "blue", fontSize: "20px" }}
                        icon={faFolderOpen}
                        title="Open"
                      />{" "}
                    </button>
                  </div>
                </li>
              ))}
            </ul>

            <button
              className={styles.closeModalBtn}
              onClick={() => setShowPendingPopup(false)}
            >
              X
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ListofDocument;
