import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import styles from "./Navbar.module.css";

export default function Navbar() {
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  const handleLogout = () => {
    try {
      window.open("https://uat.zustpe.com/account/session/end", "_self");
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <div className={`${styles.sidebar} ${collapsed ? styles.collapsed : ""}`}>
      <div className={styles["crm-user-title"]}>
        {collapsed ? "Z" : "Zustpe CMS"}
      </div>
      <nav>
        <ul>
          <li>
            <Link to="/cms/nav">Dashboard</Link>
          </li>
          <li>
            <Link to="/cms/nav/listofclient">List of clients</Link>
          </li>
          <li>
            <Link to="/cms/nav/Documents">Documents</Link>
          </li>
          <li>
            <Link to="/cms/nav/SharedWithMe">Shared with me</Link>
          </li>
          <li>
        <Link   onClick={handleLogout} className={styles.crmLogout}>
          Logout
        </Link>

          </li>
        </ul>
      </nav>

    </div>
  );
}
