import React from 'react'
import styles from "./LandingPage.module.css";

import featureImage1 from '../../assets/picture1.jpg'; // Feature image 1
import featureImage2 from '../../assets/picture2.jpg'; // Feature image 2
import featureImage3 from '../../assets/picture3.jpg'; // Feature image 3
export default function LandingPage() {
    const IDP = async () => {
        window.open(`${window.location.origin}/cms/login`, "_self");

      };
  return (
    <div className={styles.container}>
    <header className={styles.header}>
      <div className={styles.navbar}>
        <nav>
          <ul>
            <li><a href="#features">Features</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a onClick={IDP} className={styles.ctaBtn}>login</a></li>
          </ul>
        </nav>
      </div>
    </header>

    {/* Hero Section */}
    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <h1 className={styles.title}>Simplify Your Contract Management</h1>
        <p className={styles.subtitle}>
          Streamline your contract processes, ensure compliance, and automate workflows with ease. All in one platform.
        </p>
        <button className={styles.button} onClick={IDP}>Get Started</button>
      </div>
    </section>

    {/* Features Section */}
    <section id="features" className={styles.features}>
      <h2 className={styles.sectionTitle}>Key Features</h2>
      <div className={styles.featureItem}>
        <img src={featureImage1} alt="Centralized Dashboard" />
        <div className={styles.featureText}>
          <h3>Centralized Dashboard</h3>
          <p>Access and manage all your contracts in one place. View details, track status, and search with ease.</p>
        </div>
      </div>
      <div className={styles.featureItem}>
        <img src={featureImage2} alt="Automated Reminders" />
        <div className={styles.featureText}>
          <h3>Automated Reminders</h3>
          <p>Set and receive automated reminders for renewals, expirations, and key milestones.</p>
        </div>
      </div>
      <div className={styles.featureItem}>
        <img src={featureImage3} alt="Secure & Compliant" />
        <div className={styles.featureText}>
          <h3>Secure & Compliant</h3>
          <p>Your contracts are protected with the highest security standards and fully compliant with regulations.</p>
        </div>
      </div>
    </section>

    {/* Footer Section */}
    <footer id="contact" className={styles.footer}>
      <div className={styles.footerContent}>
        <div className={styles.footerLogo}>ContractManage</div>
        <p>&copy; 2024 ContractManage. All Rights Reserved.</p>
        <nav>
          <ul>
            <li><a href="#privacy-policy">Privacy Policy</a></li>
            <li><a href="#terms">Terms of Service</a></li>
          </ul>
        </nav>
      </div>
    </footer>
  </div>
  
  )
}
