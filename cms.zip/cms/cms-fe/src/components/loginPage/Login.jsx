import React, { useEffect } from "react";
import styles from "./Login.module.css"
import { useNavigate } from "react-router-dom";
import axios from "axios";


const LoginPage = () => {
    const navigate = useNavigate();
    const code = new URLSearchParams(window.location.search).get("code");
    const state = new URLSearchParams(window.location.search).get("state");
    const iss = new URLSearchParams(window.location.search).get("iss");
  
    useEffect(() => {
      const IdpVerify = async () => {
        const params = new URLSearchParams();
        params.append("code", code);
        params.append("state", state);
        params.append("iss", iss);
  
        try {
          const response = await axios.post(
            `${window.location.origin}/cms/idpverify`,
            params,
            {
              headers: {
                "Content-Type": "application/x-www-form-urlencoded",
              },
              withCredentials: true,
            }
          );
  
          if (response.status === 200) {
            console.log(response.data);
      
            localStorage.setItem("token", response.data.token);
          }
          const token = localStorage.getItem("token");
          if (token) {
            navigate("/cms/nav");
          }
        } catch (error) {
          console.log(error.message, "saffdsfdgf");
        }
      };
      IdpVerify();
    }, []);

  return (
    <div className={styles.loaderContainer}>
      <div className={styles.loader}></div>
    </div>
  );
};

export default LoginPage;
