import React from 'react'
import Navbar from '../navbar/Navbar'
import './Layout.css'
import { Outlet } from 'react-router-dom'

export default function Layout() {
  return (
    <div className="LayoutSidebar">
        <Navbar/>
        <Outlet/>
    </div>
  )
}
