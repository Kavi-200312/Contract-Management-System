import React, { useEffect, useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import axiosInstance from "../../utils/axiosInstance";
import styles from "./Client.module.css";

export default function Client() {
  const [showForm, setShowForm] = useState(false);
  const [clients, setClients] = useState([]);
  const [formData, setFormData] = useState({
    name: "",
    mobileNumber: "",
    email: "",
    role: [], // Initialize as an empty array for roles
  });
  // console.log(clients);
  const [userDetails, setUserDetails] = useState("");

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await axiosInstance.get("/userDetails");
        const userData = response.data.data;
        // console.log(userData);
        setUserDetails(userData);
        // console.log(userData.mobileNumber);
      } catch (error) {
        toast.error("Something went wrong");
      }
    };
    fetchUser();
  }, []);

  const [errors, setErrors] = useState({});
  const [fetchError, setFetchError] = useState("");
  const [loading, setLoading] = useState(true);
  const handleCheckboxArrayChange = (e) => {
    const { value, checked } = e.target;

    let updatedRoles = [...formData.role];

    if (checked) {
      // Add role if checked
      if (!updatedRoles.includes(value)) {
        updatedRoles.push(value);
      }
    } else {
      // Remove role if unchecked
      updatedRoles = updatedRoles.filter((role) => role !== value);
    }

    setFormData({ ...formData, role: updatedRoles });

    let formErrors = { ...errors };

    // Validation for role selection
    if (updatedRoles.length === 0) {
      formErrors.role = "At least one role must be selected.";
    } else {
      formErrors.role = "";
    }

    setErrors(formErrors);
  };

  const fetchClients = async () => {
    try {
      const response = await axiosInstance.get("/getclients");
      setClients(response.data.data); // Set the fetched clients data
      setLoading(false);
    } catch (err) {
      toast.error("Failed to fetch client data");
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchClients();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validateIndianNumber = (number) => {
    const mobileRegex = /^[6-9][0-9]{9}$/;
    return mobileRegex.test(number);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });

    let formErrors = { ...errors };

    switch (name) {
      case "name":
        if (!value) {
          formErrors.name = "Name is required.";
        } else if (!/^[A-Za-z\s]+$/.test(value)) {
          formErrors.name = "Only letters and spaces are allowed.";
        } else {
          formErrors.name = "";
        }
        break;

      case "mobileNumber":
        if (!value) {
          formErrors.mobileNumber = "Mobile number is required.";
        } else if (!validateIndianNumber(value)) {
          formErrors.mobileNumber =
            "Must be a 10-digit number starting with 6-9.";
        } else {
          const existingClient = clients.find(
            (client) =>
              client.mobileNumber === value &&
              client.role.includes(...formData.role)
          );
          if (existingClient) {
            formErrors.mobileNumber =
              "Mobile number already exists for the selected role.";
            toast.error("Mobile number already exists for the selected role.");
          } else {
            formErrors.mobileNumber = "";
          }
        }
        break;

      case "email":
        if (!value) {
          formErrors.email = "Email is required.";
        } else if (!validateEmail(value)) {
          formErrors.email = "Please enter a valid email address.";
        } else {
          const existingClient = clients.find(
            (client) =>
              client.email === value && client.role.includes(...formData.role)
          );
          if (existingClient) {
            formErrors.email = "Email already exists for the selected role.";
            toast.error("Email already exists for the selected role.");
          } else {
            formErrors.email = "";
          }
        }
        break;

      default:
        break;
    }

    setErrors(formErrors);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    let formErrors = {};

    // Validate all fields before submission
    if (!formData.name) {
      formErrors.name = "Name is required.";
    } else if (!/^[A-Za-z\s]+$/.test(formData.name)) {
      formErrors.name = "Only letters and spaces are allowed.";
    }

    if (!formData.mobileNumber) {
      formErrors.mobileNumber = "Mobile number is required.";
    } else if (!validateIndianNumber(formData.mobileNumber)) {
      formErrors.mobileNumber = "Must be a 10-digit number starting with 6-9.";
    } else {
      // Check for duplicates, excluding the logged-in user
      const existingClient = clients.find(
        (client) =>
          (client.mobileNumber === formData.mobileNumber &&
            Array.isArray(formData.role) &&
            formData.role.length > 0 && // Ensure role is an array and not empty
            formData.role.some((role) => client.role.includes(role))) ||
          client.mobileNumber === userDetails.mobileNumber // Check if any role matches
      );
      if (existingClient) {
        formErrors.mobileNumber = "Mobile number already exists for this role.";
        toast.error("Mobile number already exists for this role.");
      }
    }

    if (!formData.email) {
      formErrors.email = "Email is required.";
    } else if (!validateEmail(formData.email)) {
      formErrors.email = "Please enter a valid email address.";
    } else {
      // Check for duplicates, excluding the logged-in user
      const existingClient = clients.find(
        (client) =>
          client.email === formData.email &&
          Array.isArray(formData.role) &&
          formData.role.length > 0 && // Ensure role is an array and not empty
          formData.role.some((role) => client.role.includes(role)) // Check if any role matches
      );
      if (existingClient) {
        formErrors.email = "Email already exists for this role.";
        toast.error("Email already exists for this role.");
      }
    }

    if (!formData.role || formData.role.length === 0) {
      formErrors.role = "At least one role must be selected.";
    }

    setErrors(formErrors);

    // Prevent submission if there are any errors
    if (Object.keys(formErrors).length > 0) {
      return; // Stop execution if errors exist
    }

    // Prepare the payload and make the API request
    const payload = {
      ...formData,
      role: formData.role, // Ensure roles are sent as an array
    };

    try {
      await axiosInstance.post("/client", payload);
      toast.success("Added successfully", { autoClose: 2000 });
      setFormData({ name: "", mobileNumber: "", email: "", role: [] });
      setShowForm(false);
      fetchClients(); // Refresh the client list
    } catch (error) {
      console.error("Error saving process:", error);
      toast.error(
        error.response?.data?.message ||
          "Failed to save client. Please try again.",
        { autoClose: 3000 }
      );
    }
  };

  return (
    <div className={styles.mainClientDiv}>
      <ToastContainer />
      <button className={styles.addButton} onClick={() => setShowForm(true)}>
        Add
      </button>

      <div className={styles.Client}>
        <h1>Client List</h1>
        <table className={styles.table} border="1">
          <thead>
            <tr>
              <th className={styles.th}>Name</th>
              <th className={styles.th}>Mobile Number</th>
              <th className={styles.th}>Email</th>
            </tr>
          </thead>
          <tbody>
            {clients.filter((client) => client.role === "client").length > 0 ? (
              clients
                .filter((client) => client.role === "client")
                .map((client, index) => (
                  <tr key={index} className={styles.tr}>
                    <td className={styles.td}>{client.name}</td>
                    <td className={styles.td}>{client.mobileNumber}</td>
                    <td className={styles.td}>{client.email}</td>
                  </tr>
                ))
            ) : (
              <tr>
                <td
                  colSpan="3"
                  className={styles.td}
                  style={{ textAlign: "center" }}
                >
                  No clients found.
                </td>
              </tr>
            )}
          </tbody>
        </table>

        <h1>Collaborator List</h1>
        <table className={styles.table} border="1">
          <thead>
            <tr>
              <th className={styles.th}>Name</th>
              <th className={styles.th}>Mobile Number</th>
              <th className={styles.th}>Email</th>
            </tr>
          </thead>

          <tbody>
            {clients.filter((client) => client.role === "collaborator").length >
            0 ? (
              clients
                .filter((client) => client.role === "collaborator")
                .map((client, index) => (
                  <tr key={index} className={styles.tr}>
                    <td className={styles.td}>{client.name}</td>
                    <td className={styles.td}>{client.mobileNumber}</td>
                    <td className={styles.td}>{client.email}</td>
                  </tr>
                ))
            ) : (
              <tr>
                <td
                  colSpan="3"
                  className={styles.td}
                  style={{ textAlign: "center" }}
                >
                  No collaborators found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className={styles.popup} onClick={() => setShowForm(false)}>
          <div
            className={styles["popup-content"]}
            onClick={(e) => e.stopPropagation()}
          >
            <h4 style={{ textAlign: "center" }}>Add Client & Collaborator</h4>
            <form onSubmit={handleSubmit} autoComplete="off">
              <div>
                <label htmlFor="name">Name:</label>
                <input
                  type="text"
                  name="name"
                  id="name"
                  className={styles.input}
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                />
                {errors.name && <p className={styles.error}>{errors.name}</p>}
              </div>

              <div>
                <label htmlFor="mobileNumber">Mobile Number:</label>
                <input
                  type="text"
                  name="mobileNumber"
                  id="mobileNumber"
                  maxLength={10}
                  className={styles.input}
                  value={formData.mobileNumber}
                  onChange={handleInputChange}
                  required
                />
                {errors.mobileNumber && (
                  <p className={styles.error}>{errors.mobileNumber}</p>
                )}
              </div>

              <div>
                <label htmlFor="email">Email:</label>
                <input
                  type="email"
                  name="email"
                  id="email"
                  className={styles.input}
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                />
                {errors.email && <p className={styles.error}>{errors.email}</p>}
              </div>

              <div>
                <label>Role</label>
                <div>
                  <label className={styles.checkboxes}>
                    <input
                      type="checkbox"
                      name="role"
                      value="client"
                      checked={formData.role.includes("client")}
                      onChange={handleCheckboxArrayChange}
                    />
                    Client
                  </label>
                  <label className={styles.checkboxes}>
                    <input
                      type="checkbox"
                      name="role"
                      value="collaborator"
                      checked={formData.role.includes("collaborator")}
                      onChange={handleCheckboxArrayChange}
                    />
                    Collaborator
                  </label>
                </div>
              </div>

              <div className={styles.btnDiv}>
                <button className={styles.button} type="submit">
                  Submit
                </button>
                <button
                  className={styles.closebtn}
                  onClick={() => setShowForm(false)}
                >
                  Close
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
