import React, {  useEffect, useState } from "react";
import styles from "./Dashboard.module.css";
import axiosInstance from "../../utils/axiosInstance";
import { useLocation, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";

function Dashboard() {
  const location = useLocation();
  const addDocumentPopup = location.state?.value;
  const [addPopup, setAddPopup] = useState(addDocumentPopup || false);
  const navigate = useNavigate();
  const [clients, setClients] = useState([]);

  const [documentStatusCounts, setDocumentStatusCounts] = useState({
    Draft: 0,
    FollowUp: 0,
    Active: 0,
    Expired: 0,
  });

  useEffect(() => {
    // Define an async function inside the useEffect
    async function fetchData() {
      try {
        const response = await axiosInstance.get("/getStatusCount");
        const status = response.data.statusCount; // Array of document status

        const statusCounts = { Draft: 0, FollowUp: 0, Active: 0, Expired: 0 };

        // Loop through the status data and increment the respective count
        status.forEach((doc) => {
          if (
            doc.documentStatus &&
            statusCounts[doc.documentStatus] !== undefined
          ) {
            statusCounts[doc.documentStatus]++;
          }
        });

        // Update state with the counted status values
        setDocumentStatusCounts(statusCounts);
      } catch (error) {
        toast.error("Something went wrong");
      }
    }

    // Call the async function to fetch the data
    fetchData();
  }, []); // Empty dependency array to run only once when the component mounts

  const [parties, setParties] = useState([
    { party: "party 1", clientName: "", clientMobileNumber: "" },
    { party: "party 2", clientName: "", clientMobileNumber: "" },
  ]);
  const [userDetails, setUserDetails] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await axiosInstance.get("/userDetails");
        const userData = response.data.data;
        console.log(userData);

        // Set party 1 details with user data
        setParties((prevParties) => [
          {
            ...prevParties[0],
            clientName: userData.name,
            clientMobileNumber: userData.mobileNumber,
          },
          ...prevParties.slice(1),
        ]);

        setUserDetails(userData);
      } catch (error) {
        toast.error("Something went wrong");
      }
    };
    fetchUser();
  }, []);

  // Handle changes to party selection
  const handlePartyChange = (e, index) => {
    const [name, mobile] = e.target.value.split("-");
    setParties((prevParties) =>
      prevParties.map((party, i) =>
        i === index
          ? { ...party, clientName: name, clientMobileNumber: mobile }
          : party
      )
    );
  };

  // Add a new party (limit to 10)
  const addParty = () => {
    if (parties.length >= 10) {
      toast.warning("You can only add up to 10 parties");
      return;
    }
    setParties((prevParties) => [
      ...prevParties,
      {
        party: `party ${prevParties.length + 1}`,
        clientName: "",
        clientMobileNumber: "",
      },
    ]);
  };

  // Remove an existing party
  const removeParty = (index) => {
    setParties((prevParties) => prevParties.filter((_, i) => i !== index));
  };
  useEffect(() => {
    const fetchClients = async () => {
      try {
        const response = await axiosInstance.get("/getclients");
        setClients(response.data.data); // Set the fetched clients data
      } catch (err) {
        toast.error("Failed to fetch client data");
      }
    };

    fetchClients();
  }, []);

  // State for form inputs
  const [formValues, setFormValues] = useState({
    documentName: "",
    size: "",
    collaborator: "",
    duration: "",
  });

  // State for validation errors
  const [formErrors, setFormErrors] = useState({});

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    if (name === "collaborator" && value) {
      const parts = value.split("-");
      if (parts.length === 2) {
        const [collaboratorName, collaboratorMobileNumber] = parts;

        // Update form values for collaborator details
        setFormValues({
          ...formValues,
          collaborator: value,
          collaboratorName: collaboratorName.trim(),
          collaboratorMobileNumber: collaboratorMobileNumber.trim(),
        });

        // Clear errors for collaborator
        setFormErrors((prevErrors) => ({
          ...prevErrors,
          collaborator: "",
        }));
      } else {
        // Set error if format is invalid
        setFormErrors((prevErrors) => ({
          ...prevErrors,
          collaborator: "Invalid format. Expected 'Name-MobileNumber'.",
        }));
      }
      return; // Exit after processing 'collaborator'
    }

    if (name === "duration") {
      if (value) {
        const selectedDate = new Date(value);
        const today = new Date();
        const maxDate = new Date(
          today.getFullYear() + 100,
          today.getMonth(),
          today.getDate()
        );

        if (selectedDate < today) {
          setFormErrors((prevErrors) => ({
            ...prevErrors,
            duration: "Invalid Date. Date cannot be in the past.",
          }));
        } else if (selectedDate > maxDate) {
          setFormErrors((prevErrors) => ({
            ...prevErrors,
            duration:
              "Invalid Date. Date cannot be more than 100 years from today.",
          }));
        } else {
          setFormErrors((prevErrors) => ({ ...prevErrors, duration: "" }));
        }

        // Update the value for duration
        setFormValues({
          ...formValues,
          [name]: value,
        });
      } else {
        // Clear error and value if the field is empty
        setFormErrors((prevErrors) => ({ ...prevErrors, duration: "" }));
        setFormValues({
          ...formValues,
          [name]: "",
        });
      }
      return; // Exit after processing 'duration'
    }

    // General input handling for all other fields
    if (value.length <= 35) {
      setFormValues({
        ...formValues,
        [name]: value,
      });

      // Clear error for this field if previously set
      setFormErrors((prevErrors) => ({
        ...prevErrors,
        [name]: "",
      }));
    } else {
      // Set error message for exceeding character limit
      setFormErrors((prevErrors) => ({
        ...prevErrors,
        [name]: "Maximum 35 characters allowed.",
      }));
    }
  };

  // Validate inputs
  const validateInputs = () => {
    const errors = {};
    if (!formValues.documentName.trim()) {
      errors.documentName = "Document Name is required";
    }
    if (!formValues.size) {
      errors.size = "Size is required";
    }
    if (!formValues.collaboratorName.trim()) {
      errors.collaborator = "Collaborator is required";
    }
    if (!formValues.collaboratorMobileNumber.trim()) {
      errors.collaborator = "Collaborator moblie number is required";
    }
    return errors;
  };

  // Handle form submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(parties.length,".................",parties)
    const errors = validateInputs();
     // Validate parties length
  if (parties.length < 2) {
    errors.parties = "At least two parties are required.";
  }
    if (Object.keys(errors).length === 0) {
      try {
        const response = await axiosInstance.post("/saveDocumentDetails", {
          ...formValues,
          parties,
          status: "Draft",
        });

        if (response.status === 201) {
          // console.log("Form submitted successfully:", response.data);
          setAddPopup(false); // Close the popup
          setFormValues({
            documentName: "",
            size: "",
            collaborator: "",
          }); // Reset form
          navigate("/cms/nav/quillEditor", {
            state: { formValues: response.data.document },
          });
        }
      } catch (error) {
        console.error("Error submitting form:", error);
        if (error.response) {
          // Server responded with a status other than 200 range
          toast.error(error.response.data.message);
          // alert(error.response.data.message || "Failed to submit the form.");
        } else {
          alert("An error occurred. Please try again later.");
        }
      }
    } else {
      setFormErrors(errors);
    }
  };

  return (
    <div className={styles.Dashboard}>
      <ToastContainer />

      <div className={styles.cardContainer}>
        <div className={`${styles.card} ${styles.draft}`}>
          Draft:
          <div className={styles.documentStatusCounts}>
            {documentStatusCounts.Draft}
          </div>
        </div>
        <div className={`${styles.card} ${styles.followup}`}>
          Follow-up:
          <div className={styles.documentStatusCounts}>
            {" "}
            {documentStatusCounts.FollowUp}
          </div>
        </div>
        <div className={`${styles.card} ${styles.active}`}>
          Active:
          <div className={styles.documentStatusCounts}>
            {documentStatusCounts.Active}
          </div>
        </div>
        <div className={`${styles.card} ${styles.expired}`}>
          Expired:
          <div className={styles.documentStatusCounts}>
            {documentStatusCounts.Expired}
          </div>
        </div>
      </div>
      <button onClick={() => setAddPopup(true)}>Add Document</button>

      {addPopup && (
        <>
          <div className={styles.overlay} onClick={() => setAddPopup(false)} />
          <div className={styles.addForm}>
            <form onSubmit={handleSubmit}>
              <label htmlFor="documentName">Document Name</label>
              <input
                type="text"
                id="documentName"
                name="documentName"
                placeholder="Document Name"
                required
                value={formValues.documentName}
                onChange={handleInputChange}
              />
              {formErrors.documentName && (
                <span className={styles.error}>{formErrors.documentName}</span>
              )}

              <label htmlFor="size">Size</label>
              <select
                id="size"
                name="size"
                value={formValues.size}
                onChange={handleInputChange}
                required
              >
                <option value="" disabled>
                  Select Size
                </option>
                <option value="A4">A4</option>
                <option value="A3">A3</option>
                <option value="Letter">Letter</option>
                <option value="Legal">Legal</option>
                <option value="Tabloid">Tabloid</option>
                <option value="Executive">Executive</option>
                <option value="Statement">Statement</option>
              </select>
              {formErrors.size && (
                <span className={styles.error}>{formErrors.size}</span>
              )}

              <div className={styles.selectDropdown}>
                <label htmlFor="collaborator" className={styles.collaborator}>
                  Collaborator:
                  <select
                    name="collaborator"
                    id="collaborator"
                    value={formValues.collaborator || ""}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="" disabled>
                      Select Collaborator
                    </option>
                    {clients
                      .filter((client) => client.role === "collaborator")
                      .map((client, index) => (
                        <option
                          key={index}
                          value={`${client.name}-${client.mobileNumber}`}
                        >
                          {client.name} ({client.mobileNumber})
                        </option>
                      ))}
                  </select>
                </label>
                {formErrors.collaborator && (
                  <span className={styles.error}>
                    {formErrors.collaborator}
                  </span>
                )}
              </div>
              <label htmlFor="duration">Duration</label>
              <input
                type="Date"
                id="duration"
                name="duration"
                min={new Date().toISOString().split("T")[0]}
                max={
                  new Date(
                    new Date().getFullYear() + 100,
                    new Date().getMonth(),
                    new Date().getDate()
                  )
                    .toISOString()
                    .split("T")[0]
                }
                required
                value={formValues.duration}
                onChange={handleInputChange}
              />
              {formErrors.duration && (
                <span className={styles.error}>{formErrors.duration}</span>
              )}

              <div className={styles.dynamicParties}>
                <label>Add Counter Party</label>
                {parties.map((party, index) => (
                  <div key={index} className={styles.partyRow}>
                    <label htmlFor={`party-${index}`}>{`Party ${
                      index + 1
                    }`}</label>

                    {/* Party 1: Show static details */}
                    {index === 0 ? (
                      <div className={styles.party1}>
                        <p style={{ margin: "0" }}>
                          {party.clientName} ({party.clientMobileNumber})
                        </p>
                      </div>
                    ) : (
                      // Dropdown for other parties
                      <select
                        id={`party-${index}`}
                        name={`party-${index}`}
                        value={
                          party.clientName && party.clientMobileNumber
                            ? `${party.clientName}-${party.clientMobileNumber}`
                            : ""
                        }
                        onChange={(e) => handlePartyChange(e, index)}
                        required
                      >
                        <option value="" disabled>
                          Select a Client
                        </option>
                        {clients
                          .filter(
                            (client) =>
                              client.role === "client" &&
                              !parties.some(
                                (p, i) =>
                                  i !== index && p.clientName === client.name // Allow the current selection
                              )
                          )
                          .map((client) => (
                            <option
                              key={client.mobileNumber}
                              value={`${client.name}-${client.mobileNumber}`}
                            >
                              {client.name} ({client.mobileNumber})
                            </option>
                          ))}
                      </select>
                    )}

                    {index !== 0 && (
                      <button
                        type="button"
                        className={styles.removeParty}
                        onClick={() => removeParty(index)}
                      >
                        ✖
                      </button>
                    )}
                  </div>
                ))}
                {parties.length < 10 && (
                  <button
                    type="button"
                    className={styles.addParty}
                    onClick={addParty}
                  >
                    + Add Party
                  </button>
                )}
              </div>

              <button type="submit" className={styles.button}>
                Submit
              </button>
              <button
                type="button"
                className={styles.button}
                onClick={() => setAddPopup(false)}
              >
                Cancel
              </button>
            </form>
          </div>
        </>
      )}
    </div>
  );
}

export default Dashboard;
