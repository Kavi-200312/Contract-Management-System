import React, { useEffect, useState, useRef } from "react";
import { useLocation } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import ReactQuill from "react-quill";
import axiosInstance from "../../utils/axiosInstance";
import QuillToolbar, { modules, formats } from "./QuillToolBar"; // Import toolbar configuration

import "react-quill/dist/quill.snow.css"; // Quill CSS
import "react-toastify/dist/ReactToastify.css"; // Toast CSS

const QuillEditor = () => {
  const location = useLocation();
  const contentFromFile = location.state?.contentFromFile || ""; // Get file content
  const formValues = location.state?.formValues || {}; // Get document details
  // const pendingDocument =location.state?.pendingDocument ||{}

  const [content, setContent] = useState(contentFromFile);
  const [editorSize, setEditorSize] = useState("A4"); // Default editor size
  const [isReadOnly, setIsReadOnly] = useState(false); // Read-only mode
  const quillRef = useRef(null);
  const [pendingApproval, setPendingApproval] = useState("");

  // Set editor size and permission mode based on formValues
  useEffect(() => {
    if (formValues.size) {
      setEditorSize(formValues.size);
    }
    if (formValues.permission === "Read Only") {
      setIsReadOnly(true); // Disable editing
    } else {
      setIsReadOnly(false); // Enable editing
    }
  }, [formValues]);

  const handleChange = (value) => {
    setContent(value);
  };
  const handleAction = async (action) => {
    // setPendingApproval(action)
    handleSave(action);
  };

  const handleSave = async (action) => {
    if (!quillRef.current) {
      toast.error("Quill editor is not initialized.");
      return;
    }

    try {
      const editorContent = quillRef.current.getEditor().root.innerHTML;
      const { uniqueIdDoc, uniqueSharedDocId, ...restFormValues } = formValues; // Destructure formValues

      // Decide which API to call based on the presence of uniqueIdDoc or uniqueSharedDocId
      let response;

      if (uniqueIdDoc !== undefined && uniqueSharedDocId !== undefined) {
        console.log(uniqueSharedDocId, "..................", uniqueIdDoc);
        // If uniqueIdDoc exists, call updateDocumentDetails API
        response = await axiosInstance.put("/updateDocumentDetails", {
          ...restFormValues,
          uniqueIdDoc,
          uniqueSharedDocId,
          content: editorContent,
          pendingApproval: action,
        });
      } else if (uniqueIdDoc) {
        // If uniqueIdDoc exists, call updateDocumentDetails API
        response = await axiosInstance.put("/updateDocumentDetails", {
          ...restFormValues,
          uniqueIdDoc,
          content: editorContent,
        });
      } else if (uniqueSharedDocId) {
        // If uniqueSharedDocId exists, call updateSharedDocument API
        response = await axiosInstance.put("/updateSharedDocument", {
          ...restFormValues,
          uniqueSharedDocId,
          content: editorContent,
        });
      } else {
        toast.error("Document ID or Shared Document ID is required.");
        return;
      }

      if (response.data.code === 409) {
        toast.info(response.data.message);
      } else if (response.data.code === 400) {
        toast.error(response.data.message);
      } else if (response.data.code === 404) {
        toast.error(response.data.message);
      } else if (response.status === 200) {
        toast.success(response.data.message);
      } else {
        toast.error("Failed to save the document.");
      }
    } catch (error) {
      toast.error("An error occurred while saving the document.");
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="editor-container">
      <ToastContainer />

      {!isReadOnly && (
        <QuillToolbar
          handleSave={handleSave}
          handlePrint={handlePrint}
          handleAction={
            formValues.uniqueIdDoc && formValues.uniqueSharedDocId
              ? handleAction
              : null
          }
        />
      )}

      <ReactQuill
        key={isReadOnly ? "readonly" : "editable"} // Force re-render based on readOnly state
        ref={quillRef}
        value={content}
        onChange={handleChange}
        modules={isReadOnly ? { toolbar: false } : modules} // Disable toolbar if read-only
        formats={formats}
        theme="snow"
        readOnly={isReadOnly} // Set read-only mode
        className={`editor ${
          isReadOnly ? "ql-read-only" : "" // Add class for read-only state
        } ${
          editorSize === "A4"
            ? "a4-size"
            : editorSize === "A3"
            ? "a3-size"
            : editorSize === "Letter"
            ? "letter-size"
            : editorSize === "Legal"
            ? "legal-size"
            : editorSize === "Tabloid"
            ? "tabloid-size"
            : editorSize === "Statement"
            ? "statement-size"
            : editorSize === "Executive"
            ? "executive-size"
            : ""
        }`}
      />
    </div>
  );
};

export default QuillEditor;
