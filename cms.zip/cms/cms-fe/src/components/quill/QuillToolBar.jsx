import React from "react";
import { Quill } from "react-quill";
import "../../index.css";
import axiosInstance from "../../utils/axiosInstance";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCheck,
  faDoorOpen,
  faPrint,
  faSave,
  faTimes,
  faUser,
} from "@fortawesome/free-solid-svg-icons";
import { Tooltip } from "react-tooltip";

const CustomUndo = () => (
  <svg viewBox="0 0 18 18">
    <polygon className="ql-fill ql-stroke" points="6 10 4 12 2 10 6 10" />
    <path
      className="ql-stroke"
      d="M8.09,13.91A4.6,4.6,0,0,0,9,14,5,5,0,1,0,4,9"
    />
  </svg>
);

// Redo button icon component for Quill editor
const CustomRedo = () => (
  <svg viewBox="0 0 18 18">
    <polygon className="ql-fill ql-stroke" points="12 10 14 12 16 10 12 10" />
    <path
      className="ql-stroke"
      d="M9.91,13.91A4.6,4.6,0,0,1,9,14a5,5,0,1,1,5-5"
    />
  </svg>
);

// Undo and redo functions for Custom Toolbar
function undoChange() {
  this.quill.history.undo();
}
function redoChange() {
  this.quill.history.redo();
}

// Add sizes to whitelist and register them
const Size = Quill.import("formats/size");
Size.whitelist = [
  "10px",
  "12px",
  "14px",
  "16px",
  "18px",
  "20px",
  "24px",
  "28px",
  "32px",
  "34px",
  "36px",
  "38px",
  "40px",
];
Quill.register(Size, true);
// Dynamically inject CSS for custom sizes
const injectDynamicCSS = (sizes) => {
  const style = document.createElement("style");
  sizes.forEach((size) => {
    style.innerHTML += `.ql-size-${size} { font-size: ${size}; }`;
  });
  document.head.appendChild(style);
};

// Call this function during initialization
injectDynamicCSS(Size.whitelist);

// Add fonts to whitelist and register them
const Font = Quill.import("formats/font");

// Updated whitelist with standardized names
Font.whitelist = [
  "arial",
  "comic-sans",
  "courier-new",
  "georgia",
  "helvetica",
  "lucida",
  "times-new-roman",
  "arial-black",
  "courier-new",
  "impact",
  "lucida-console",
  "tahoma",
  "verdana",
  "comic-sans-ms",
  "garamond",
  "palatino",
  "bookman",
  "candara",
  "consolas",
  "didot",
  "franklin-gothic-medium",
  "gill-sans",
  "optima",
  "rockwell",
  "century-gothic",
  "lucida-sans",
  "segoe-ui",
  "Trebuchet MS",
  "Baskerville",
  "Perpetua",
  "Futura",
  "Bodoni MT",
  "Calisto MT",
  "Copperplate",
  "Merriweather",
  "Playfair Display",
  "Roboto",
  "Open Sans",
  "Lato",
];

// Register the updated Font format with Quill
Quill.register(Font, true);

// Corrected injectDynamicCSSForFontFamily function
const injectDynamicCSSForFontFamily = (fontList) => {
  const style = document.createElement("style");

  fontList.forEach((font) => {
    const className = font.toLowerCase().replace(/\s+/g, "-"); // Replace spaces with dashes
    style.innerHTML += `.ql-font-${className} { font-family: ${font}; }\n`;
  });

  document.head.appendChild(style);
};

// Inject the dynamic CSS for the fonts
injectDynamicCSSForFontFamily(Font.whitelist);

// Modules object for setting up the Quill editor
export const modules = {
  toolbar: {
    container: "#toolbar",
    handlers: {
      undo: undoChange,
      redo: redoChange,
    },
  },
  history: {
    delay: 500,
    maxStack: 100,
    userOnly: true,
  },
};

// Formats objects for setting up the Quill editor
export const formats = [
  "header",
  "font",
  "size",
  "italic",
  "underline",
  "align",
  "bold",
  "strike",
  "script",
  "blockquote",
  "background",
  "list",
  "bullet",
  "indent",
  "link",
  "image",
  "color",
  "code-block",
];

// Quill Toolbar component
export const QuillToolbar = ({ handleSave, handlePrint, handleAction }) => {
  const navigate = useNavigate();

  return (
    <div id="toolbar">
      <span className="ql-formats">
        <select className="ql-font" defaultValue="arial">
          {Font.whitelist.map((font, index) => (
            <option key={`${font}-${index}`} value={font.toLowerCase()}>
              {font}
            </option>
          ))}
        </select>
        <select className="ql-size" defaultValue="14px">
          {Size.whitelist.map((size) => (
            <option key={size} value={size}>
              {size}
            </option>
          ))}
        </select>
        <select className="ql-header" defaultValue="3">
          <option value="1">Heading 1</option>
          <option value="2">Heading 2</option>
          <option value="3">Heading 3</option>
          <option value="4">Heading 4</option>
          <option value="5">Heading 5</option>
          <option value="6">Heading 6</option>
        </select>
      </span>
      <span className="ql-formats">
        <button className="ql-bold" />
        <button className="ql-italic" />
        <button className="ql-underline" />
        <button className="ql-strike" />
      </span>
      <span className="ql-formats">
        <button className="ql-list" value="ordered" />
        <button className="ql-list" value="bullet" />
        <button className="ql-indent" value="-1" />
        <button className="ql-indent" value="+1" />
      </span>
      <span className="ql-formats">
        <button className="ql-script" value="super" />
        <button className="ql-script" value="sub" />
        <button className="ql-blockquote" />
        <button className="ql-direction" />
      </span>
      <span className="ql-formats">
        <select className="ql-align" />
        <select className="ql-color" />
        <select className="ql-background" />
      </span>
      <span className="ql-formats">
        <button className="ql-link" />
        <button className="ql-image" />
        <button className="ql-video" />
      </span>
      <span className="ql-formats">
        <button className="ql-formula" />
        <button className="ql-code-block" />
        <button className="ql-clean" />
      </span>
      <span className="ql-formats">
        <button className="ql-undo" title="undo">
          <CustomUndo />
        </button>
        <button className="ql-redo" title="redo">
          <CustomRedo />
        </button>
        {!handleAction && (
          <button onClick={handleSave} title="save">
            {" "}
            <FontAwesomeIcon
              style={{ color: "green", fontSize: "20px" }}
              icon={faSave}
            />
          </button>
        )}
        <button onClick={handlePrint} title="print">
          <FontAwesomeIcon
            style={{ color: "blue", fontSize: "20px" }}
            icon={faPrint}
          />
        </button>
        <button
          onClick={() => {
            navigate("/cms/nav/Documents");
          }}
          data-tip="Exit"
        >
          <FontAwesomeIcon
            style={{ color: "red", fontSize: "20px" }}
            icon={faDoorOpen}
          />
        </button>
        {handleAction && (
          <>
            <button onClick={() => handleAction("reject")}>
              {" "}
              <FontAwesomeIcon
                style={{ color: "red", fontSize: "20px" }}
                icon={faTimes}
                title="Reject"
              />{" "}
            </button>
            <button onClick={() => handleAction("accept")}>
              {" "}
              <FontAwesomeIcon
                style={{ color: "green", fontSize: "20px" }}
                icon={faCheck}
                title="Accept"
              />{" "}
            </button>
          </>
        )}
      </span>
      <Tooltip place="top" effect="solid" />
    </div>
  );
};

export default QuillToolbar;
