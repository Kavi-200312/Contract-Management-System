
import React, { useState, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import { useNavigate } from "react-router-dom";
import styles from "./SharedDocument.module.css"; // Assuming you have a CSS module for styling
import axiosInstance from "../../utils/axiosInstance";
import {
  faCheck,
  faFolderOpen,
  faPaperPlane,
  faTimes,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const SharedWithMe = () => {
  const [sharedDocuments, setSharedDocuments] = useState([]);
  const navigate = useNavigate();

  // Fetch shared document data when component mounts
  const handleApproval = async (document, action) => {
    try {
      console.log("Document Details:", document);
      console.log("Action:", action);

      // Prepare the payload to send to the API
      const payload = {
        document,
        action, 
      };

      // Make the API call using axios
      const response = await axiosInstance.post(
        "/updateApprovalStatus",
        payload
      );

      // Check the response status and show the corresponding toast message
      if (response.status === 200) {
        toast.success(`Document ${action}ed successfully.`);

        // Update the document state to reflect the approval status
        setSharedDocuments((prevDocuments) =>
          prevDocuments.map((doc) =>
            doc.uniqueSharedDocId === document.uniqueSharedDocId
              ? { ...doc, approval: action } // Update approval status
              : doc
          )
        );
      } else {
        toast.error(`Failed to ${action} the document.`);
      }
    } catch (error) {
      console.error("Error updating approval status:", error);
      toast.error("An error occurred. Please try again.");
    }
  };

  useEffect(() => {
    const fetchSharedDocuments = async () => {
      try {
        const response = await axiosInstance.get("/getSharedDocuments");
        setSharedDocuments(response.data.sharedDocuments);
      } catch (error) {
        console.error("Error fetching shared documents:", error);
        toast.error("Failed to load shared documents.");
      }
    };

    fetchSharedDocuments();
  }, []);

  // Handle opening a file for viewing or editing
  const handleOpenFile = async (document) => {
    try {
      console.log(document);

      const filePath = document.duplicateFilePath; // Use the duplicate file path

      if (!filePath) {
        toast.info("File is missing....");
        return;
      }
      const response = await axiosInstance.get(
        `/getDocumentContent/${filePath}`
      );
      const fileContent = response.data.content;

      navigate("/cms/nav/quillEditor", {
        state: { contentFromFile: fileContent, formValues: document },
      });
    } catch (error) {
      console.error("Error opening file:", error);
      toast.error("Failed to open file.");
    }
  };

  // Handle Send action for documents with write access
  const handleSendAction = async (document) => {
    console.log(document);
    try {
      const response = await axiosInstance.post(
        "/submitUpdateRequest",
        document
      );
      if (response.status === 200) {
        toast.success(`Sended to ${document.sharedByName}`);
      } else {
        toast.error("something wrong");
      }
    } catch (error) {
      console.error("Error handling send action:", error);
      toast.error("Failed to send the document.");
    }
  };

  return (
    <div className={styles.container}>
      <h1>Shared Document List</h1>
      <table className={styles.table}>
        <thead>
          <tr>
            <th>Shared By</th>
            <th>Shared By Mobile</th>
            <th>My Role</th>
            <th>Access</th>
            <th>File</th>
            <th>Approval</th>
            <th>Action</th>
            <th>Share</th>
          </tr>
        </thead>
   

        <tbody>
          {sharedDocuments.length > 0 ? (
            sharedDocuments.map((document, index) => (
              <tr key={index}>
                <td className={styles.td}>{document.sharedByName}</td>
                <td className={styles.td}>{document.sharedByMobileNumber}</td>
                <td className={styles.td}>{document.role}</td>
                <td className={styles.td}>{document.permission}</td>
                <td className={styles.td}>
                  <button
                    className={styles.partyButton}
                    onClick={() => handleOpenFile(document)}
                  >
                    <FontAwesomeIcon
                      style={{ color: "blue", fontSize: "20px" }}
                      icon={faFolderOpen}
                      title="Open"
                    />{" "}
                  </button>
                </td>

                {document.permission === "Write" ? (
                  <td className={styles.td}>
                    {/* Approval Status */}
                    {document.approval ? (
                      <span className={styles[document.approval]}>
                        {document.approval}
                      </span>
                    ) : (
                      <span>Pending</span>
                    )}
                  </td>
                ) : (
                  <td>No action</td>
                )}

                {/* Approval Buttons */}
                <td className={styles.td}>
                  <div className={styles.actionIcons}>
             
                    <FontAwesomeIcon
                      style={{
                        color: document.role === "client" ? "green" : "gray",
                        fontSize: "20px",
                        cursor:
                          document.role === "client"
                            ? "pointer"
                            : "not-allowed", // Allow pointer for clients
                        marginLeft: "10px",
                      }}
                      icon={faCheck}
                      onClick={
                        () =>
                          document.role === "client" &&
                          handleApproval(document, "accept") // Only execute for clients
                      }
                    />
                    <FontAwesomeIcon
                      style={{
                        color: document.role === "client" ? "red" : "gray",
                        fontSize: "20px",
                        cursor:
                          document.role === "client"
                            ? "pointer"
                            : "not-allowed", // Allow pointer for clients
                      }}
                      icon={faTimes}
                      onClick={
                        () =>
                          document.role === "client" &&
                          handleApproval(document, "reject") // Only execute for clients
                      }
                    />
                  </div>
                </td>

                {/* Send Button */}
                {document.permission === "Write" ? (
                  <td className={styles.td}>
                    <button
                      className={styles.sendButton}
                      onClick={() => handleSendAction(document)}
                    >
                      <FontAwesomeIcon
                        style={{ color: "green", fontSize: "20px" }}
                        icon={faPaperPlane}
                        title="Send"
                      />
                    </button>
                  </td>
                ) : (
                  <td className={styles.td}>
                    <span className={styles.noAction}>No Action</span>
                  </td>
                )}
              </tr>
            ))
          ) : (
            <tr>
              <td
                colSpan="7"
                className={styles.td}
                style={{ textAlign: "center" }}
              >
                No Documents found.
              </td>
            </tr>
          )}
        </tbody>
      </table>
      <ToastContainer />
    </div>
  );
};

export default SharedWithMe;
