

const { default: axios } = require("axios");

// Token verification middleware function
const verifyJWT = async (req, res, next) => {
  const token = req.headers["authorization"];

  // Check if token is provided
  if (!token) {
    return res.status(400).json({message: "Token is missing." });
  }

  try {
    // Fetch user data from the API to get the hash
    const response = await axios.get("https://uat.zustpe.com/account/me", {
      headers: {
        Authorization: token,
      },
    });

    const hash = response.data;
    console.log(hash);
    

    // Check if the response contains the expected hash
    if (!hash) {
      return res.status(400).json({message: "Hash not found in the response." });
    }

      req.user = hash;
      return next();  // Proceed to the next middleware or route handler
 

  } catch (error) {
    // Handle errors from the axios request or the database query
    console.error("Error during token verification:", error.message);
    return res.status(500).json({ message: "Internal server error during verification." });
  }
};

module.exports = { verifyJWT };
