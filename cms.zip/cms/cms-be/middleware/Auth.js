


const { default: axios } = require("axios");
const { idpTokenModel } = require("../models/IdpModel");

// Token verification function
const verifyTokenAndHash = async (req, res) => {
  const { token } = req.body;

  // Check if token is provided
  if (!token) {
    return res.status(400).json({ isValid: false, message: "Token is missing." });
  }

  let hash;
  
  try {
    // Fetch user data from the API to get the hash
    const response = await axios.get("https://uat.zustpe.com/account/me", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    // Check if the response contains the expected hash
    if (!response.data.hash) {
      return res.status(400).json({ isValid: false, message: "Hash not found in the response." });
    }

    hash = response.data.hash;
    console.log("Hash:", hash);
    
  } catch (error) {
    // Handle errors from the axios request
    console.error("An error occurred while fetching the user data:", error);
    return res.status(500).json({ isValid: false, message: "Error fetching user data from the API." });
  }

  try {
    // Find the token record by hash in the database
    const tokenRecord = await idpTokenModel.findOne({ hash });

    if (!tokenRecord) {
      // If no record is found for the hash
      return res.status(404).json({ isValid: false, message: "User not found with this hash." });
    }

    // Check if the access token matches
    if (tokenRecord.accessToken === token) {
      return res.status(200).json({ isValid: true, message: "Token and hash are valid." });
    } else {
      return res.status(401).json({ isValid: false, message: "Invalid token." });
    }

  } catch (error) {
    // Handle errors from the database query
    console.error("Error verifying token:", error.message);
    return res.status(500).json({ isValid: false, message: "Internal server error during verification." });
  }
};

module.exports = { verifyTokenAndHash };
