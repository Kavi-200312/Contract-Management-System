const express = require("express");
require("dotenv").config();
const cors = require("cors");
const connectDB = require("./database/database");
const router = require("./routes/routes");

const session = require("express-session");
const helmet = require("helmet");
const passport = require("passport");
const cookieParser = require("cookie-parser");
const { Issuer, Strategy } = require("openid-client");
const { UserInfo, idpTokenModel } = require("./models/IdpModel");
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

connectDB();

app.use("/cms", router); 

app.use(
  cors({
    origin: "http://192.168.29.14:3000",
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    credentials: true,
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

app.use(express.json({ limit: "15mb" }));
app.use(session({ secret: "secret", resave: false, saveUninitialized: true}));
app.use(helmet());
app.use(passport.initialize());
app.use(passport.session());

passport.serializeUser(function (user, done) {
  done(null, user);
});
passport.deserializeUser(function (user, done) {
  done(null, user);
});


Issuer.discover(process.env.OIDC_ZUSTPE_URL).then(function (oidcIssuer) {
  const client = new oidcIssuer.Client({
    client_id: process.env.CLIENT_ID, 
    client_secret: process.env.CLIENT_SECRET,
    redirect_uris: [process.env.REDIRECT_URL],
    response_types: ['code'],
  });

  passport.use(
    "oidc",
    new Strategy(
      { client, passReqToCallback: true },
      async (req, tokenSet, userinfo, done) => {
        let data;
        if (tokenSet && userinfo) {
          // console.log('TokenSet:', tokenSet);
          // console.log('UserInfo:', userinfo);

          // Prepare data for the response
          data = {
            Auth_token: tokenSet.access_token,
            hash: userinfo.hash,
          };

          try {
            // Check if the user exists by hash in the UserInfo model
            let userDetails = await UserInfo.findOneAndUpdate(
              { hash: userinfo.hash },  // Find by hash
              {
                name: userinfo.name,
                mobileNumber: userinfo.phone_number,
                scopes: userinfo.scopes,
                sub: userinfo.sub,
              },
              { new: true, upsert: true }  // If user doesn't exist, create a new record
            );

            // Update or create the user token information in idpTokenModel
            let tokenDetails = await idpTokenModel.findOneAndUpdate(
              { hash: userinfo.hash },  // Find by hash
              {
                mobileNumber: userinfo.phone_number,
                accessToken: tokenSet.access_token,
                refreshToken: tokenSet.refresh_token,
                expireTime: tokenSet.expires_at,
                jwt: tokenSet.id_token,
              },
              { new: true, upsert: true }  // If token doesn't exist, create a new record
            );
            // console.log(tokenDetails,"...........................",userDetails);
            
            // Return the updated data to the callback function
            return done(null, data);
          } catch (err) {
            console.error("Error in saving or updating user data:", err);
            return done("Error in saving user data", false);
          }
        } else {
          return done("Auth error", false);
        }
      }
    )
  );
});


app.get(
  "/cms/login",
  function (req, res, next) {

    next();
    0;
  },
  passport.authenticate("oidc", { scope: "openid refresh_token" })
);


app.post("/cms/idpverify", passport.authenticate("oidc"),async(req,res,next)=>{
  try {
    // return res.status(200).json({message:"Success"})
    // console.log(req.user.Auth_token);
    return res.status(200).json({ token: req.user.Auth_token, code: 200 });
  } catch (error) {
    return res.status(500).json({message:"Something wrong"})
  }
});

// app.post("/cms/idpverify", async (req, res, next) => {
//   try {
//     // Authenticate using passport
//     await new Promise((resolve, reject) => {
//       passport.authenticate("oidc", (err, user, info) => {
//         if (err) {
//           reject(err);
//         } else if (!user) {
//           reject(new Error("Authentication failed"));
//         } else {
//           req.user = user;
//           resolve();
//         }
//       })(req, res, next);
//     });

//     // Proceed with your logic after successful authentication
//     console.log(req.user.Auth_token);
//    res.status(200).json({ token: req.user.Auth_token, hash: req.user.hash, code: 200 });
   
//   } catch (error) {
//     return res.status(500).json({ message: "Something went wrong", error: error.message });
//   }
// });




app.get("/cms/user", (req, res) => {
  res.header("Content-Type", "application/json");
  res.end(
    JSON.stringify(
      { tokenset: req.session.tokenSet, userinfo: req.session.userinfo },
      null,
      2
    )
  );
});



const PORT = process.env.PORT || 4000;
const server = app.listen(PORT, () => {
  console.log(`Server is connected on http://localhost:${PORT}`);
});
server.on("request", (req, res) => {
  console.log(req.method, ">>>>>>>>>>>>", req.originalUrl);
});
