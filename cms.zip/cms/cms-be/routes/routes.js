const { addClient, getClient } = require("../controllers/Client");
const { submitUpdateRequest, handleApprovePendingFile } = require("../controllers/DocumentApproveRequest");
const { createDocument, updateDocument, getDocuments, getDocumentwithParams, getStatusCount, addPartyToDocument, updateStatus } = require("../controllers/Documents");
const { shareDocumentDetails, getSharedDocuments, updateSharedDocument, handleApproval } = require("../controllers/SharedDocumentDetails");
const { userDetails } = require("../controllers/UserDetails");
const { verifyTokenAndHash } = require("../middleware/Auth");
const { verifyJWT } = require("../middleware/verifyUser");

const router = require("express").Router()

//user
router.get('/userDetails',verifyJWT,userDetails)

// router.use(verifyJWT)
//Document
router.post('/saveDocumentDetails',verifyJWT,createDocument)
router.put('/updateDocumentDetails',verifyJWT,updateDocument)
router.put('/upateStatus',verifyJWT,updateStatus)
router.get('/getDocuments',verifyJWT,getDocuments)
router.get('/getDocumentContent/:filePath',verifyJWT,getDocumentwithParams)
router.get('/getStatusCount',verifyJWT,getStatusCount)
router.post('/updateParty',verifyJWT,addPartyToDocument)

//Client
router.post('/client',verifyJWT,addClient)
router.get('/getclients',verifyJWT,getClient)

//share Document Datails
router.post('/sendDetailstoCC',verifyJWT,shareDocumentDetails)
router.get('/getSharedDocuments', verifyJWT, getSharedDocuments);
router.put('/updateSharedDocument',verifyJWT,updateSharedDocument)
router.post('/updateApprovalStatus',verifyJWT,handleApproval)

//Document Request
router.post('/submitUpdateRequest',verifyJWT,submitUpdateRequest)
router.post('/handleApprovePendingFile',verifyJWT,handleApprovePendingFile)


//auth
router.post('/authendicate',verifyTokenAndHash)
module.exports =router;

