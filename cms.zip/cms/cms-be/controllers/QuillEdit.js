const quillModel = require("../models/QuilModel");

const saveDocument = async (req, res) => {
  const { key, title, data } = req.body;

  if (!key || !title) {
    return res.status(400).json({ error: "Key and Title are required" });
  }

  try {

    // Save or update document in the database
    const document = await quillModel.findOneAndUpdate(
      { key },
      { title, data },
      { new: true, upsert: true }
    );

    res.status(200).json(document);
  } catch (error) {
    console.error("Error saving document:", error);
    res.status(500).json({ error: "Failed to save document", details: error.message });
  }
};

const getDocument = async (req, res) => {
  const { key } = req.params;

  try {

    // Fetch document from the database
    const document = await quillModel.findOne({ key });

    if (!document) {
      return res.status(404).json({ error: "Document not found" });
    }

    res.status(200).json(document);
  } catch (error) {
    console.error("Error fetching document:", error);
    res.status(500).json({ error: "Failed to fetch document", details: error.message });
  }
};

module.exports = { saveDocument, getDocument };
