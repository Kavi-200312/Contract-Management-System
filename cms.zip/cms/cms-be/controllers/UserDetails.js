const { UserInfo } = require("../models/IdpModel");

const userDetails = async(req,res)=>{
try {
    const user = req.user;
    const userDetail = await UserInfo.findOne({hash:user.hash})
    if(!userDetail){
        return res.status(404).json({message:"user not found"})
    } 
    const onlyData = {
        name:userDetail.name,
        mobileNumber:userDetail.mobileNumber,
    }
    return res.status(200).json({message:"successfully fetched user details",data:onlyData})
    
} catch (error) {
    console.error("Error fetching user deatails:", error);
    res.status(500).json({ message: "Error fetching user deatails." });
}
}

module.exports={userDetails}