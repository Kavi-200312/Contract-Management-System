const ClientModel = require("../models/ClientModel");

// Add a new customer
// const addClient = async (req, res) => {
//   try {
//     const { name, mobileNumber, email ,role} = req.body;
//     const user = req.user;


//     // Validation for name (must be 3 to 35 characters, only letters and spaces)
//     const namePattern = /^[A-Za-z\s]{3,35}$/;
//     if (!name || !namePattern.test(name)) {
//       return res.status(400).json({
//         message: "Name is required and must be between 3 to 35 characters, containing only letters and spaces.",
//       });
//     }

//     // Validation for mobile number (must be a 10-digit number starting with 6-9)
//     const mobilePattern = /^[6-9][0-9]{9}$/;
//     if (!mobileNumber || !mobilePattern.test(mobileNumber)) {
//       return res.status(400).json({
//         message: "Mobile number must be a 10-digit number starting with 6, 7, 8, or 9.",
//       });
//     }

//     // Validation for email (basic email format check)
//     const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!email || !emailPattern.test(email)) {
//       return res.status(400).json({
//         message: "Email must be a valid email address.",
//       });
//     }
//     if (!role) {
//       return res.status(400).json({
//         message: "Role must be a Required.",
//       });
//     }

//     // Check if the customer already exists
//     const existingCustomer = await ClientModel.findOne({ mobileNumber,hash:user.hash ,role,email});

//     if (existingCustomer) {
//       return res.status(409).json({ message: "Already exists." });
//     }

//     // Create a new customer
//     const customer = new ClientModel({ name, mobileNumber, email,role ,hash:user.hash});
//     await customer.save();
//     const onlyData = {
//         name:customer.name,
//         mobileNumber:customer.mobileNumber,
//         email:customer.email,
//         role:customer.role
//     }

//     res.status(201).json({
//       message: "Client added successfully.",
//       data:onlyData,
//     });
//   } catch (error) {
//     console.error("Error adding customer:", error);
//     res.status(500).json({ message: "Internal server error." });
//   }
// };
const addClient = async (req, res) => {
  try {
    const { name, mobileNumber, email, role } = req.body;
    const user = req.user;

    // Validation for name (must be 3 to 35 characters, only letters and spaces)
    const namePattern = /^[A-Za-z\s]{3,35}$/;
    if (!name || !namePattern.test(name)) {
      return res.status(400).json({
        message: "Name is required and must be between 3 to 35 characters, containing only letters and spaces.",
      });
    }

    // Validation for mobile number (must be a 10-digit number starting with 6-9)
    const mobilePattern = /^[6-9][0-9]{9}$/;
    if (!mobileNumber || !mobilePattern.test(mobileNumber)) {
      return res.status(400).json({
        message: "Mobile number must be a 10-digit number starting with 6, 7, 8, or 9.",
      });
    }

    // Validation for email (basic email format check)
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailPattern.test(email)) {
      return res.status(400).json({
        message: "Email must be a valid email address.",
      });
    }

    // Validation for role
    if (!role || role.length === 0) {
      return res.status(400).json({
        message: "Role is required.",
      });
    }

    // If role is an array with two items (client, collaborator), create two records
    if (Array.isArray(role) && role.length === 2) {
      const roles = ['client', 'collaborator'];

      const customerData = {
        name,
        mobileNumber,
        email,
        hash: user.hash,
      };

      // Create records for both roles
      const clientRecord = new ClientModel({ ...customerData, role: roles[0] });
      const collaboratorRecord = new ClientModel({ ...customerData, role: roles[1] });

      // Save both clients
      await clientRecord.save();
      await collaboratorRecord.save();

      const clientData = {
        name: clientRecord.name,
        mobileNumber: clientRecord.mobileNumber,
        email: clientRecord.email,
        role: clientRecord.role,
      };

      const collaboratorData = {
        name: collaboratorRecord.name,
        mobileNumber: collaboratorRecord.mobileNumber,
        email: collaboratorRecord.email,
        role: collaboratorRecord.role,
      };

      return res.status(201).json({
        message: "Clients added successfully with different roles.",
        data: [clientData, collaboratorData], // Return both client and collaborator data
      });
    } else if (Array.isArray(role) && role.length === 1) {
      // If role is an array with one item, create one record
      const customerData = {
        name,
        mobileNumber,
        email,
        hash: user.hash,
      };

      const clientRecord = new ClientModel({ ...customerData, role: role[0] });

      await clientRecord.save();

      const onlyData = {
        name: clientRecord.name,
        mobileNumber: clientRecord.mobileNumber,
        email: clientRecord.email,
        role: clientRecord.role,
      };

      return res.status(201).json({
        message: "Client added successfully.",
        data: onlyData,
      });
    } else {
      // If role is not provided in the expected format, return error
      return res.status(400).json({
        message: "Role should be either one ('client' or 'collaborator') or both ('client' and 'collaborator').",
      });
    }
  } catch (error) {
    console.error("Error adding client:", error);
    res.status(500).json({ message: "Internal server error." });
  }
};

const getClient = async (req, res) => {
    try {
      // Fetch all clients from the database
      const user = req.user;

      const clients = await ClientModel.find({hash:user.hash});
  
      // Map the clients to extract only the necessary fields (name, mobileNumber, email)
      const onlyData = clients.map((item) => {
        return {
          name: item.name,
          mobileNumber: item.mobileNumber,
          email: item.email,
          role: item.role,
          uniqueId:item.uniqueId
        };
      });
  
      // Send the mapped data as a response
      res.status(200).json({message:"data fetched successfully",data:onlyData});
    } catch (error) {
      // Handle errors (e.g., database connection issues)
      console.error('Error fetching clients:', error);
      res.status(500).json({ message: 'Internal server error.' });
    }
  };
  


module.exports = {addClient,getClient}