const DocumentModel = require("../models/DocumentModel");
const { UserInfo } = require("../models/IdpModel");
const SharedDocumentModel = require("../models/SharedDocumentModel");

const submitUpdateRequest = async (req, res) => {
  try {
    const { uniqueSharedDocId, duplicateFilePath } = req.body;

    // Validate payload
    if (!uniqueSharedDocId || !duplicateFilePath) {
      return res.status(400).json({ message: "Invalid payload." });
    }

    // Find the shared document details using uniqueSharedDocId
    const sharedDocumentDetails = await SharedDocumentModel.findOne({
      uniqueSharedDocId,
    });

    if (!sharedDocumentDetails) {
      return res
        .status(404)
        .json({ message: "Shared document details not found." });
    }

    const { originalDocumentId } = sharedDocumentDetails;

    // Fetch the original document using the ID
    const document = await DocumentModel.findById(originalDocumentId);

    if (!document) {
      return res.status(404).json({ message: "Original document not found." });
    }

    // Fetch the updated user's details
    const user = req.user;
    const updatedUser = await UserInfo.findOne({ hash: user.hash });

    if (!updatedUser) {
      return res.status(404).json({ message: "User not found." });
    }

    // Get the latest version or set to 1 if no history exists
    const latestVersion =
      document.history.length > 0
        ? document.history[document.history.length - 1].version + 0.1
        : 1.0;

    // Add the update to the history array
    const historyUpdate = {
      version: parseFloat(latestVersion.toFixed(1)), // Store version with 1 decimal precision
      filePath: decodeURIComponent(duplicateFilePath),
      //   filePath: duplicateFilePath,
      updatedBy: `${updatedUser.name} (${updatedUser.mobileNumber})`,
      timestamp: new Date(),
    };

    // Add the new history entry
    document.history.push(historyUpdate);

    // Add the update request to the pendingUpdates array
    const updateRequest = {
      //   proposedFilePath: decodeURIComponent(duplicateFilePath),
      proposedFilePath: duplicateFilePath,
      uniqueSharedDocId: uniqueSharedDocId,
      updatedBy: `${updatedUser.name} (${updatedUser.mobileNumber})`,
      timestamp: new Date(),
    };

    if (!document.pendingUpdates) {
      document.pendingUpdates = [];
    }

    document.pendingUpdates.push(updateRequest);

    // Save the document with the new history and pending update
    await document.save();
    // console.log(document);

    res.status(200).json({
      message: "Update request submitted successfully.",
      pendingUpdates: document.pendingUpdates,
      history: document.history,
    });
  } catch (error) {
    console.error("Error handling update request:", error);
    res.status(500).json({ message: "Internal server error." });
  }
};

const handleApprovePendingFile = async (req, res) => {
  try {
    const { uniqueSharedDocId, uniqueIdDoc ,approval} = req.body;
    if (uniqueSharedDocId) {
      const sharedDocApproval = await SharedDocumentModel.findOne({
        uniqueSharedDocId,
      });
      if (sharedDocApproval) {
        sharedDocApproval.approval = approval;
        await sharedDocApproval.save();
        return res.status(200).json({meassage:"Approval updated"})
      }
    }
    return res.status(200).json({meassage:"unqiue Document id is missing", code:400})

  } catch (error) {
    return res.status(500).json({ message: "server error" });
  }
};

module.exports = { submitUpdateRequest,handleApprovePendingFile };
