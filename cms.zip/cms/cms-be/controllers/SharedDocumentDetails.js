const DocumentModel = require("../models/DocumentModel");
const fs = require("fs");
const path = require("path");
const SharedDocumentModel = require("../models/SharedDocumentModel");
const { UserInfo } = require("../models/IdpModel");

const shareDocumentDetails = async (req, res) => {
  try {
    const {
      uniqueIdDoc,
      shareDetails,
      collaboratorName,
      collaboratorMobileNumber,
      counterParties,
      filePath,
      permission
    } = req.body;

    const user = req.user; // Logged-in user details
    const sharedUser = await UserInfo.findOne({ hash: user.hash });
    const originalDocument = await DocumentModel.findOne({ uniqueIdDoc });

    if (!originalDocument) {
      return res.status(404).json({ message: "Original document not found." });
    }

    const decodedFilePath = decodeURIComponent(filePath);

    // Handle Collaborator Sharing
    if (shareDetails === "collaborator") {
      const newVersion = "1.0"; // Initial version for collaborators
      const newFilePath = path.join(
        path.dirname(decodedFilePath),
        `${path.basename(
          decodedFilePath,
          path.extname(decodedFilePath)
        )}-collaborator-v${newVersion}${path.extname(decodedFilePath)}`
      );

      fs.copyFileSync(decodedFilePath, newFilePath); // Duplicate file

      const sharedDocument = new SharedDocumentModel({
        originalDocumentId: originalDocument._id,
        sharedByName: sharedUser.name,
        sharedByMobileNumber: sharedUser.mobileNumber,
        sharedToName: collaboratorName,
        sharedToMobileNumber: collaboratorMobileNumber,
        role: "collaborator",
        permission: permission || "Write",
        version: newVersion,
        duplicateFilePath: encodeURIComponent(newFilePath),
        size: originalDocument.size,
      });

      await sharedDocument.save();
    }

    // Handle Client Sharing
    if (shareDetails === "client" && counterParties?.length > 0) {
      const selectedClients = counterParties.filter((party) => party.selected);

      for (const client of selectedClients) {
        const latestVersion = await SharedDocumentModel.find({
          originalDocumentId: originalDocument._id,
        })
          .sort({ sharedDate: -1 })
          .limit(1);

        const newVersion = latestVersion.length
          ? (parseFloat(latestVersion[0].version) + 0.1).toFixed(1)
          : "1.1";

        const newFilePath = path.join(
          path.dirname(decodedFilePath),
          `${path.basename(
            decodedFilePath,
            path.extname(decodedFilePath)
          )}-client-${client.clientName}-v${newVersion}${path.extname(
            decodedFilePath
          )}`
        );

        fs.copyFileSync(decodedFilePath, newFilePath); // Duplicate file

        const sharedDocument = new SharedDocumentModel({
          originalDocumentId: originalDocument._id,
          sharedByName: sharedUser.name,
          sharedByMobileNumber: sharedUser.mobileNumber,
          sharedToName: client.clientName,
          sharedToMobileNumber: client.clientMobileNumber,
          role: "client",
          permission: client.permission,
          version: newVersion,
          duplicateFilePath: encodeURIComponent(newFilePath),
          size: originalDocument.size,
        });

        await sharedDocument.save();
      }
    }

    res.status(200).json({ message: "Document shared successfully!" });
  } catch (error) {
    console.error("Error sharing document details:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

const getSharedDocuments = async (req, res) => {
  try {
    // Assuming req.user contains the logged-in user's information (e.g., mobile number)
    const user = req.user; // Logged-in user details
    const sharedUser = await UserInfo.findOne({ hash: user.hash });
    const userMobileNumber = sharedUser.mobileNumber;

    // Find all shared documents where the user is either the 'sharedBy' or 'sharedTo'
    const sharedDocuments = await SharedDocumentModel.find({
      sharedToMobileNumber: userMobileNumber,
    });

    const onlyData = sharedDocuments.map((i) => {
      return {
        sharedByName: i.sharedByName,
        sharedByMobileNumber: i.sharedByMobileNumber,
        role: i.role,
        permission: i.permission,
        uniqueSharedDocId: i.uniqueSharedDocId,
        sharedDate: i.sharedDate,
        duplicateFilePath: i.duplicateFilePath,
        size: i.size,
        approval:i.approval
      };
    });
    // Send the shared documents back as response
    res.status(200).json({
      message: "Shared documents fetched successfully!",
      sharedDocuments: onlyData,
    });
  } catch (error) {
    console.error("Error fetching shared documents:", error);
    res.status(500).json({
      message: "Internal server error",
      error: error.message,
    });
  }
};

// const updateSharedDocument = async (req, res) => {
//   try {
//     const {
//       uniqueSharedDocId,  // Shared Document unique ID
//       content,  // Updated content (HTML)
//       permission,  // Updated permission
//       role,  // Updated role
//       duplicateFilePath,  // Updated file path
//       sharedByMobileNumber,  // Updated mobile number of the person sharing
//       sharedByName,  // Updated name of the person sharing
//       sharedDate,  // Date of sharing
//     } = req.body;

//     // Validate incoming data
//     if (!uniqueSharedDocId) {
//       return res.status(400).json({ message: "Shared Document ID is required." });
//     }
//     if (!content) {
//       return res.status(400).json({ message: "Content is required." });
//     }
//     if (!permission || !["Read Only", "Write"].includes(permission)) {
//       return res.status(400).json({ message: "Invalid permission value." });
//     }
//     if (!role || !["collaborator", "client"].includes(role)) {
//       return res.status(400).json({ message: "Invalid role value." });
//     }
//     if (!duplicateFilePath) {
//       return res.status(400).json({ message: "Duplicate file path is required." });
//     }
//     if (!sharedByMobileNumber || !sharedByName) {
//       return res.status(400).json({ message: "Shared by details are required." });
//     }
//     if (!sharedDate) {
//       return res.status(400).json({ message: "Shared date is required." });
//     }

//     // Find the shared document using uniqueSharedDocId
//     const sharedDocument = await SharedDocumentModel.findOne({ uniqueSharedDocId });

//     if (!sharedDocument) {
//       return res.status(404).json({ message: "Shared document not found." });
//     }

//     // Update the shared document details
//     sharedDocument.permission = permission;  // Update permission
//     sharedDocument.role = role;  // Update role
//     sharedDocument.duplicateFilePath = duplicateFilePath;  // Update duplicate file path
//     sharedDocument.sharedByMobileNumber = sharedByMobileNumber;  // Update mobile number
//     sharedDocument.sharedByName = sharedByName;  // Update name
//     sharedDocument.sharedDate = new Date(sharedDate);  // Update the date of sharing

//     // Save the updated shared document in the database
//     await sharedDocument.save();

//     // Send a success response
//     res.status(200).json({ message: "Shared document updated successfully!" });
//   } catch (error) {
//     console.error("Error updating shared document:", error);
//     res.status(500).json({ message: "Internal server error", error: error.message });
//   }
// };

const updateSharedDocument = async (req, res) => {
  try {
    const {
      uniqueSharedDocId, // Shared Document unique ID
      content, // Updated content (HTML)
      permission, // Updated permission
      role, // Updated role
      duplicateFilePath, // Updated file path
      sharedByMobileNumber, // Updated mobile number of the person sharing
      sharedByName, // Updated name of the person sharing
      sharedDate, // Date of sharing
    } = req.body;

    // Validate incoming data
    if (!uniqueSharedDocId) {
      return res
        .status(400)
        .json({ message: "Shared Document ID is required." });
    }
    if (!content) {
      return res.status(400).json({ message: "Content is required." });
    }
    if (!permission || !["Read Only", "Write"].includes(permission)) {
      return res.status(400).json({ message: "Invalid permission value." });
    }
    if (!role || !["collaborator", "client"].includes(role)) {
      return res.status(400).json({ message: "Invalid role value." });
    }
    if (!duplicateFilePath) {
      return res
        .status(400)
        .json({ message: "Duplicate file path is required." });
    }
    if (!sharedByMobileNumber || !sharedByName) {
      return res
        .status(400)
        .json({ message: "Shared by details are required." });
    }
    if (!sharedDate) {
      return res.status(400).json({ message: "Shared date is required." });
    }

    // Find the shared document using uniqueSharedDocId
    const sharedDocument = await SharedDocumentModel.findOne({
      uniqueSharedDocId,
    });

    if (!sharedDocument) {
      return res.status(404).json({ message: "Shared document not found." });
    }

    // Update the shared document details
    sharedDocument.permission = permission; // Update permission
    sharedDocument.role = role; // Update role
    sharedDocument.duplicateFilePath = duplicateFilePath; // Update duplicate file path
    sharedDocument.sharedByMobileNumber = sharedByMobileNumber; // Update mobile number
    sharedDocument.sharedByName = sharedByName; // Update name
    sharedDocument.sharedDate = new Date(sharedDate); // Update the date of sharing

    // Save the updated content to the filesystem (overwrite or create a new file)
    const decodedFilePath = decodeURIComponent(duplicateFilePath); // Decode file path
    fs.writeFileSync(decodedFilePath, content, "utf8"); // Save content to file

    // Save the updated shared document in the database
    await sharedDocument.save();

    // Send a success response
    res.status(200).json({ message: "Shared document updated successfully!" });
  } catch (error) {
    console.error("Error updating shared document:", error);
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};


// const handleApproval = async (req, res) => {
//   try {
//     const { document, action } = req.body;
//     console.log("Document Details:", document);
//     console.log("Action:", action);

//     // Find the shared document using the uniqueSharedDocId
//     const sharedDoc = await SharedDocumentModel.findOne({
//       uniqueSharedDocId: document.uniqueSharedDocId,
//     });

//     if (!sharedDoc) {
//       return res.status(404).json({ message: "Shared document not found." });
//     }

//     // Update the approval status for the shared document
//     sharedDoc.approval = action; // Accept or Reject
//     await sharedDoc.save();
// console.log(sharedDoc);

//     // Now, find the original document using the originalDocumentId
//     const originalDoc = await DocumentModel.findOne({
//       _id: sharedDoc.originalDocumentId,
//     });

//     if (!originalDoc) {
//       return res.status(404).json({ message: "Original document not found." });
//     }

//     // Update the approval status in the counterParties array
//     const updatedCounterParties = originalDoc.counterParties.map((party) =>
//       party.clientName === document.sharedToName
//         ? { ...party, approval: action }
//         : party
//     );

//     // Save the updated original document
//     originalDoc.counterParties = updatedCounterParties;
//     await originalDoc.save();
//     console.log(originalDoc);
    
//     return res.status(200).json({ message: "Approval status updated successfully!" });
//   } catch (error) {
//     console.error("Error handling approval:", error);
//     return res.status(500).json({ message: "Internal server error", code: 500 });
//   }
// };

const handleApproval = async (req, res) => {
  try {
    const { document, action } = req.body;
    const user = req.user
    const acceptedUser = await UserInfo.findOne({hash:user.hash})
    // console.log("Document Details:", document);
    // console.log("Action:", action);

    // Find the shared document using the uniqueSharedDocId
    const sharedDoc = await SharedDocumentModel.findOne({
      uniqueSharedDocId: document.uniqueSharedDocId,
    });

    if (!sharedDoc) {
      return res.status(404).json({ message: "Shared document not found." });
    }

    // Update the approval status for the shared document
    sharedDoc.approval = action; // Accept or Reject
    await sharedDoc.save();
    // console.log("Updated Shared Document:", sharedDoc);

    // Now, find the original document using the originalDocumentId
    const originalDoc = await DocumentModel.findOne({
      _id: sharedDoc.originalDocumentId,
    });

    if (!originalDoc) {
      return res.status(404).json({ message: "Original document not found." });
    }

    // Update the approval status in the counterParties array
    const updatedCounterParties = originalDoc.counterParties.map((party, index) => {
      // If it's the first party (original owner), update their approval status too
      if (party.clientMobileNumber ===acceptedUser.mobileNumber) {
        console.log("acceptedUser");
        
        return { ...party, approval: "accept" }; // Assuming the first party is the owner
      }
      // Update the specific party's approval status
      if (party.clientMobileNumber === document.sharedByMobileNumber) {
        console.log("orignal");

        return { ...party, approval: action };
      }
      return party;
    });

    // Save the updated original document with the updated counter parties
    originalDoc.counterParties = updatedCounterParties;

    // Check if all counter parties have accepted the document
    const allApproved = originalDoc.counterParties.every(
      (party) => party.approval === "accept"
    );

    // If all counter parties have accepted, change the original document status to "Active"
    if (allApproved) {
      originalDoc.status = "Active"; // Update status to "Active"
    }

    await originalDoc.save();
    console.log("Updated Original Document:", originalDoc);

    return res.status(200).json({ message: "Approval status updated successfully!" });
  } catch (error) {
    console.error("Error handling approval:", error);
    return res.status(500).json({ message: "Internal server error", code: 500 });
  }
};



module.exports = {
  shareDocumentDetails,
  getSharedDocuments,
  updateSharedDocument,
  handleApproval,
};
