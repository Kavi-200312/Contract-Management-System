const DocumentModel = require("../models/DocumentModel");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const { log } = require("console");
const { idpTokenModel, UserInfo } = require("../models/IdpModel");
const { userDetails } = require("./UserDetails");
const SharedDocumentModel = require("../models/SharedDocumentModel");

const createDocument = async (req, res) => {
  try {
    const {
      documentName,
      size,
      collaboratorName,
      collaboratorMobileNumber,
      parties,
      status,
      duration,
    } = req.body;
    const user = req.user;
    // console.log(user);
    

    const namePattern = /^[A-Za-z\s]{3,35}$/;
    if (!collaboratorName || !namePattern.test(collaboratorName)) {
      return res.status(400).json({
        message:
          "collaboratorName is required and must be between 3 to 35 characters, containing only letters and spaces.",
      });
    }

    // Validation for mobile number (must be a 10-digit number starting with 6-9)
    const mobilePattern = /^[6-9][0-9]{9}$/;
    if (
      !collaboratorMobileNumber ||
      !mobilePattern.test(collaboratorMobileNumber)
    ) {
      return res.status(400).json({
        message:
          "collaborator Mobile number must be a 10-digit number starting with 6, 7, 8, or 9.",
      });
    }

    // Validate duration (must be between today and 100 years from today)
    if (!duration) {
      return res.status(400).json({
        message: "Duration is required.",
      });
    }

    const today = new Date();
    const maxDate = new Date(
      today.getFullYear() + 100,
      today.getMonth(),
      today.getDate()
    );
    const selectedDate = new Date(duration);

    if (selectedDate < today) {
      return res.status(400).json({
        message: "Duration cannot be in the past.",
      });
    }
    if (selectedDate > maxDate) {
      return res.status(400).json({
        message: "Duration cannot exceed 100 years from today.",
      });
    }

    // Validate status (must be one of the enum values)
    const allowedStatuses = ["Draft", "Followup", "Active", "Expired"];
    if (!status || !allowedStatuses.includes(status)) {
      return res.status(400).json({
        message: `Invalid status. Allowed values are: ${allowedStatuses.join(
          ", "
        )}.`,
      });
    }

    // Input validation for document name and size
    if (!documentName || documentName.length > 35) {
      return res.status(400).json({
        message:
          "Document Name is required and must be less than 35 characters.",
      });
    }
    if (!size) {
      return res.status(400).json({ message: "Size is required." });
    }

    // Check for existing document with the same details
    const existingDocument = await DocumentModel.findOne({
      documentName,
      size,
      collaboratorName,
      collaboratorMobileNumber,
      parties,
      // uniqueIdDoc
    });
    if (existingDocument) {
      return res.status(400).json({
        message:
          "This document name already exists. Please provide alternate details.",
      });
    }

    // Save document to database
    const newDocument = new DocumentModel({
      documentName,
      size,
      collaboratorName,
      collaboratorMobileNumber,
      counterParties: parties,
      duration: selectedDate, // Save validated duration
      status, // Save validated status
      hash:user.hash
    });

    await newDocument.save();

    const savedDocument = {
      documentName: newDocument.documentName,
      size: newDocument.size,
      collaboratorName: newDocument.collaboratorName,
      collaboratorMobileNumber: newDocument.collaboratorMobileNumber,
      uniqueIdDoc:newDocument.uniqueIdDoc,
      counterParties: newDocument.counterParties.map(
        ({ party, clientName, clientMobileNumber }) => ({
          party,
          clientName,
          clientMobileNumber,
        })
      ),
      duration: newDocument.duration, // Include duration in response
      status: newDocument.status, // Include status in response
    };

    res.status(201).json({
      message: "Document created successfully.",
      document: savedDocument,
    });
  } catch (error) {
    console.error("Error creating document:", error);
    res.status(500).json({ message: "Server error. Please try again later." });
  }
};



const getDocuments = async (req, res) => {
  try {
    const today = new Date();
    const user = req.user;

    // Fetch all documents related to the user
    const documents = await DocumentModel.find({ hash: user.hash }).lean();

    // Identify documents that have crossed their duration and are not yet marked as "Expired"
    const expiredDocuments = documents.filter(
      (doc) => new Date(doc.duration) < today && doc.status !== "Expired"
    );

    // Update the status of expired documents
    if (expiredDocuments.length > 0) {
      const expiredIds = expiredDocuments.map((doc) => doc._id);
      await DocumentModel.updateMany(
        { _id: { $in: expiredIds } },
        { $set: { status: "Expired" } }
      );
    }

const cleanedDocuments = documents.map((doc) => ({
  documentName: doc.documentName,
  size: doc.size,
  collaboratorName: doc.collaboratorName,
  collaboratorMobileNumber: doc.collaboratorMobileNumber,
  status: doc.status === "Expired" || new Date(doc.duration) < today ? "Expired" : doc.status, // Ensure client sees updated status
  filePath: doc.filePath,
  uniqueIdDoc: doc.uniqueIdDoc,
  pendingUpdates: Array.isArray(doc.pendingUpdates) ? doc.pendingUpdates.map(({ proposedFilePath, updatedBy, status, timestamp ,uniqueSharedDocId}) => ({
    proposedFilePath,
    uniqueSharedDocId,
    updatedBy,
    status,
    timestamp
  })) : [], // Ensure pendingUpdates is an array
  counterParties: doc.counterParties.map(
    ({ party, clientName, clientMobileNumber }) => ({
      party,
      clientName,
      clientMobileNumber,
    })
  ),
}));


    // Send the response
    res.status(200).json({
      message: "Documents fetched successfully.",
      documents: cleanedDocuments,
    });
  } catch (error) {
    console.error("Error fetching documents:", error);
    res.status(500).json({ message: "Error fetching documents." });
  }
};


const getDocumentwithParams = async (req, res) => {
  const { filePath } = req.params;

  try {
    // Decode the filePath to handle encoded characters
    const decodedPath = decodeURIComponent(filePath);

    // Validate the file path to prevent directory traversal attacks
    const safeBasePath = path.resolve("controllers/uploads"); // Replace with your base directory
    const resolvedPath = path.resolve(decodedPath);

    if (!resolvedPath.startsWith(safeBasePath)) {
      return res.status(400).json({ error: "Invalid file path." });
    }

    // Use fs to read the file content
    const fileContent = await fs.promises.readFile(resolvedPath, "utf8");

    // Return the content of the file
    res.status(200).json({ content: fileContent });
  } catch (error) {
    console.error("Error reading file:", error);
    res.status(500).json({ error: "Unable to fetch document content." });
  }
};

const getStatusCount = async(req,res)=>{
  try {
    const user = req.user;
    const documents = await DocumentModel.find({ hash: user.hash }).lean();
    if(!documents){
      return res.status(404).json({message:"faild to get counts"})
    }
    const status = documents.map((item) => {
      return { documentStatus: item.status };
    });
    return res.status(200).json({message:"Status count get successfully",statusCount:status})
    
  } catch (error) {
    console.log(error.message)
    return res.status(500).json({message:"Internal server error"})
    
  }
}



const updateDocument = async (req, res) => {
  try {
    const {
      content,
      uniqueSharedDocId,
      uniqueIdDoc,
      pendingApproval, // Optional: "accept" or "reject"
    } = req.body;

    // Handle shared document approval logic if pendingApproval is provided
    if (pendingApproval && uniqueSharedDocId) {
      console.log(pendingApproval);
      
      const sharedDocApproval = await SharedDocumentModel.findOne({ uniqueSharedDocId });
      console.log(sharedDocApproval);

      if (sharedDocApproval) {
        sharedDocApproval.approval = pendingApproval; // Set approval to "accept" or "reject"
        await sharedDocApproval.save();

        // If approval is "reject", respond and exit
        if (pendingApproval === "reject") {
          return res.status(200).json({
            message: "Document rejected.",
            code: 409,
          });
        }
      } else {
        return res.status(200).json({
          message: "Shared document not found with the given uniqueSharedDocId.",
          code: 404,
        });
      }
    }

    // Handle document update logic regardless of pendingApproval
    const existingDocument = await DocumentModel.findOne({ uniqueIdDoc });

    if (!existingDocument) {
      return res.status(200).json({
        message: "Document not found with the given uniqueIdDoc.",
        code: 404,
      });
    }

    // Define the upload directory
    const uploadDir = path.join(__dirname, "uploads");
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir); // Create uploads directory if it doesn't exist
    }

    let filePath = existingDocument.filePath;

    // Update file path and content only if the file path is missing
    if (!filePath) {
      filePath = path.join(uploadDir, `document-${Date.now()}.html`);
      existingDocument.filePath = encodeURIComponent(filePath); // Save the new file path
    }

    // Update document content
    // existingDocument.content = content;

    // Save content to the filesystem (overwrite or create a new file)
    fs.writeFileSync(decodeURIComponent(filePath), content, "utf8");

    // Save the updated document in the database
    await existingDocument.save();

    return res.status(200).json({
      message: "Document updated successfully!",
    });
  } catch (error) {
    console.error("Error updating document:", error);
    res.status(500).json({
      message: "An error occurred while updating the document.",
      error: error.message,
    });
  }
};

const addPartyToDocument = async (req, res) => {
  const { documentId, newParty } = req.body; // Extract documentId and newParty from the request payload

  try {
    // Validate newParty fields
    if (!newParty || !newParty.name || !newParty.mobileNumber || !newParty.role || !newParty.party) {
      return res.status(400).json({ message: "All fields (name, mobileNumber, role, party) are required." });
    }

    // Validate mobileNumber starts with 6, 7, 8, or 9
    if (!/^[6789]\d{9}$/.test(newParty.mobileNumber)) {
      return res.status(400).json({ message: "Invalid mobile number. It must start with 6, 7, 8, or 9 and be 10 digits long." });
    }

    // Validate role is "client"
    if (newParty.role !== "client") {
      return res.status(400).json({ message: "Invalid role. Only 'client' is allowed." });
    }

    // Find the document by the uniqueIdDoc field
    const document = await DocumentModel.findOne({ uniqueIdDoc: documentId });

    if (!document) {
      return res.status(404).json({ message: "Document not found." });
    }

    // Create a new party object
    const newCounterParty = {
      party: newParty.party,
      clientName: newParty.name,
      clientMobileNumber: newParty.mobileNumber,
    };

    // Add the new party to the counterParties array
    document.counterParties.push(newCounterParty);

    // Save the updated document back to the database
    await document.save();

    res.status(200).json({
      message: "Party added successfully.",
      updatedDocument: document,
    });
  } catch (error) {
    console.error("Error adding party to document:", error);
    res.status(500).json({ message: "Failed to add party.", error: error.message });
  }
};

const updateStatus = async (req, res) => {
  try {
    const { status, uniqueIdDoc } = req.body;

    if (!status || !uniqueIdDoc) {
      return res.status(400).json({ message: "Status and Document ID are required.", code: 400 });
    }

    // Find the document by uniqueIdDoc
    const findDocument = await DocumentModel.findOne({ uniqueIdDoc });
    if (!findDocument) {
      return res.status(404).json({ message: "Document not found", code: 404 });
    }

    // Update the status
    findDocument.status = status;

    // Save the document
    await findDocument.save();

    return res.status(200).json({ message: "Status successfully updated", code: 200 });
  } catch (error) {
    console.error("Error in updateStatus:", error.message);
    return res.status(500).json({ message: "Internal server error", code: 500 });
  }
};





module.exports = {
  createDocument,
  updateDocument,
  getDocuments,
  getDocumentwithParams,
  // shareDocumentDetails,
  getStatusCount,
  addPartyToDocument,
  updateStatus
};
