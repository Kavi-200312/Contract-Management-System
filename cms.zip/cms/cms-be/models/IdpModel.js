const { mongoose } = require("mongoose");
const TokenSchema = new mongoose.Schema({
  hash: {
    type: String,
    required: true,
  },
  mobileNumber: { 
    type: String,
     required: true
  },
  accessToken: {
    type: String,
    required: true,
  },
  refreshToken: {
    type: String,
    required: true,
  },
  expireTime: {
    type: Date,
    required: true,
  },
  jwt: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
    expires: "3h",
  },
});

// UserInfo Schema
const userInfoSchema = new mongoose.Schema(
  {
    mobileNumber: { type: String, required: true },
    hash: { type: String, required: true },
    name: { type: String, required: true },
    scopes: { type: [String], required: true },
    sub: { type: String, required: true },
  },
  { timestamps: true }
);

const idpTokenModel = mongoose.model("Token", TokenSchema);
const UserInfo = mongoose.model("UserInfo", userInfoSchema);

module.exports = { idpTokenModel, UserInfo };
