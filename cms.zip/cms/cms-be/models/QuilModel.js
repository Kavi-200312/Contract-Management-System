const mongoose = require("mongoose");
const connectDB = require("../database/database");

const documentSchema = new mongoose.Schema({
  key: { type: String, required: true, unique: true }, // Unique identifier for documents
  title: { type: String, required: true },
  data: { type: Object, default: {} },
});

const quillModel = mongoose.model("quilDocument", documentSchema);
module.exports = quillModel
