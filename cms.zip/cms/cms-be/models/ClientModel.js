const mongoose = require("mongoose");
const {v4 :uuidv4} = require("uuid")

const clientSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    maxlength: 35,
  },
  uniqueId:{
    type:String,
    unique:true,
    default:uuidv4
  },
  mobileNumber: {
    type: String,
    required: true,
    match: /^[6-9][0-9]{9}$/, // Indian 10-digit number validation
  },
  email: {
    type: String,
    required: true,
    trim: true,
    lowercase: true,
    match: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, // Basic email regex
  },
  role: {
    type: String,
    required: true,
    trim: true,
    enum :["client","collaborator"]
  },
  hash:{
    type:String,
    require:true
  },
}, { timestamps: true });

const ClientModel = mongoose.model("Client", clientSchema);
module.exports = ClientModel;
