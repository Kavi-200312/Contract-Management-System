const mongoose = require("mongoose");
const {v4 :uuidv4} = require("uuid")

const counterPartySchema = new mongoose.Schema({
  party: {
    type: String,
    required: true,
  },
  clientName: {
    type: String,
    required: true,
  },
  clientMobileNumber: {
    type: String,
    required: true,
  },
  approval:{
    type:String,
    enum :["reject","accept","pending"],
    default:"pending"
  }
});

const documentSchema = new mongoose.Schema(
  {
    // Existing fields
    documentName: String,
    uniqueIdDoc: { type: String, unique: true, default: uuidv4 },
    size: String,
    collaboratorName: String,
    collaboratorMobileNumber: String,
    duration: Date,
    status: { type: String, enum: ["Draft", "FollowUp", "Active", "Expired"] },
    hash: String,
    counterParties: [counterPartySchema],
    filePath: { type: String },
    content: { type: String },
    version: { type: Number, default: 1 },
    history: [
      {
        version: Number,
        filePath: String,
        content: String,
        updatedBy: String,
        timestamp: Date,
      },
    ],
    // New field for pending updates
    pendingUpdates: [
      {
        uniqueSharedDocId:String,
        proposedFilePath: String,
        updatedBy: String,
        timestamp: Date,
        status: { type: String, enum: ["Pending", "Approved", "Rejected"], default: "Pending" },
      },
    ],
  },
  { timestamps: true }
);
const DocumentModel= mongoose.model("Document", documentSchema);
module.exports = DocumentModel