const mongoose = require("mongoose");
const { v4: uuidv4 } = require("uuid");

const sharedDocumentDetailsSchema = new mongoose.Schema({
  uniqueSharedDocId: {
    type: String,
    unique: true,
    default: uuidv4, // Unique ID for the shared document
  },
  originalDocumentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Document", // Reference to the original document
  },
  sharedByName: String,
  sharedByMobileNumber: String,
  sharedToName: String,
  sharedToMobileNumber: String,
  role: {
    type: String,
    enum: ["client", "collaborator"],
  },
  permission: {
    type: String,
    enum: ["Read Only", "Write"],
  },
  sharedDate: {
    type: Date,
    default: Date.now,
  },
  version: {
    type: String, // e.g., "1.1", "1.2", etc.
    required: true,
  },
  duplicateFilePath: {
    type: String, // New file path for the duplicate
    required: true,
  },
  size:{
    type:String,
    require:true
  },
  approval:{
    type:String,
    enum :["reject","accept","pending"],
    default:"pending"
  }
});

module.exports = mongoose.model("SharedDocumentDetails", sharedDocumentDetailsSchema);
